import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

async function startServer() {
  const app = express();
  app.use(express.json({ limit: "5mb" }));

  const PORT = 3000;

  // Initialize Gemini client on the server securely
  const apiKey = process.env.GEMINI_API_KEY;
  const ai = new GoogleGenAI({
    apiKey: apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      }
    }
  });

  // Simple HTML text extractor for external web content analysis
  function cleanWebText(html: string): string {
    // Extract title
    const titleMatch = html.match(/<title[^>]*>([\s\S]*?)<\/title>/i);
    const pageTitle = titleMatch ? titleMatch[1].trim() : "";

    // Remove script, style, and head content
    let parsedText = html
      .replace(/<head[^>]*>[\s\S]*?<\/head>/gi, "")
      .replace(/<script[^>]*>[\s\S]*?<\/script>/gi, "")
      .replace(/<style[^>]*>[\s\S]*?<\/style>/gi, "")
      .replace(/<header[^>]*>[\s\S]*?<\/header>/gi, "")
      .replace(/<footer[^>]*>[\s\S]*?<\/footer>/gi, "");

    // Strip HTML Tags
    parsedText = parsedText.replace(/<[^>]+>/g, " ");

    // Normalize spacing
    parsedText = parsedText.replace(/\s+/g, " ").trim();

    return `Page Title: ${pageTitle}\n\nSelected Text Content:\n${parsedText.substring(0, 15000)}`;
  }

  // 1. Fetch text content from a given web URL
  app.post("/api/fetch-url", async (req, res): Promise<any> => {
    const { url } = req.body;

    if (!url) {
      return res.status(400).json({ error: "No URL provided." });
    }

    try {
      const parsedUrl = new URL(url);
      const isYouTube = parsedUrl.hostname.includes("youtube.com") || parsedUrl.hostname.includes("youtu.be");

      if (isYouTube) {
        let videoTitle = "YouTube Video";
        let authorName = "";
        try {
          const oembedUrl = `https://www.youtube.com/oembed?url=${encodeURIComponent(url)}&format=json`;
          const oembedResp = await fetch(oembedUrl);
          if (oembedResp.ok) {
            const oembedJson = await oembedResp.json();
            videoTitle = oembedJson.title || videoTitle;
            authorName = oembedJson.author_name || "";
          }
        } catch (e) {
          console.error("Error fetching oembed:", e);
        }

        let extractedText = "";
        if (apiKey) {
          try {
            const prompt = `Find details, a transcript summary, or a comprehensive summary of the YouTube video titled "${videoTitle}" by ${authorName} at URL: ${url}. 
Provide a high-fidelity summary/transcript of what happens in this video, including any main claims, instructions, or potential safety hazards.`;
            
            const geminiResp = await ai.models.generateContent({
              model: "gemini-2.5-flash", 
              contents: prompt,
              config: {
                systemInstruction: "You are a YouTube content research assistant. You provide an objective, extremely detailed summary of the video's content, claims, transcripts, and dialog when queried, as accurately as possible.",
                tools: [{ googleSearch: {} }] 
              }
            });

            extractedText = geminiResp.text || "";
          } catch (gem_err: any) {
            console.error("Error using Gemini for YouTube lookup:", gem_err);
            extractedText = `Title: ${videoTitle}\nAuthor: ${authorName}\n\nCould not fetch live transcripts automatically via Google Search. Topic of evaluation: "${videoTitle}" on YouTube. Please audit the video content manually or paste transcripts for deep checking.`;
          }
        } else {
          extractedText = `Title: ${videoTitle}\nAuthor: ${authorName}\n\nGEMINI_API_KEY is not configured. Please paste your transcripts or configuration below to execute the evaluation.`;
        }

        return res.json({
          title: videoTitle,
          text: extractedText,
          isYouTube: true
        });
      }

      // Fetch external content with a standard browser/fetch request
      const response = await fetch(url, {
        headers: {
          "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36",
          "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
        },
        signal: AbortSignal.timeout(6000) // 6 second limit
      });

      if (!response.ok) {
        throw new Error(`Failed to fetch URL. HTTP status: ${response.status}`);
      }

      const contentType = response.headers.get("content-type") || "";
      if (contentType.includes("application/json")) {
        const json = await response.json();
        return res.json({
          title: "JSON Resource",
          text: JSON.stringify(json, null, 2).substring(0, 15000)
        });
      }

      const html = await response.text();
      const text = cleanWebText(html);
      
      // Attempt to extract title
      const titleMatch = html.match(/<title[^>]*>([\s\S]*?)<\/title>/i);
      const title = titleMatch ? titleMatch[1].trim() : url;

      return res.json({
        title,
        text
      });
    } catch (err: any) {
      console.error("Error fetching URL:", err.message);
      return res.status(500).json({
        error: `Could not fetch or parse URL content: ${err.message}. Please manually paste the text/description list above for immediate safety auditing.`
      });
    }
  });

  // 2. Main Evaluation endpoint applying requested Prompt schema
  app.post("/api/evaluate", async (req, res): Promise<any> => {
    const { content, title, sourceType, sourceUrl } = req.body;

    if (!content || typeof content !== "string" || content.trim() === "") {
      return res.status(400).json({ error: "Raw content of the page or transcript is required." });
    }

    if (!apiKey) {
      return res.status(500).json({
        error: "GEMINI_API_KEY is not configured in Secrets. Please define it in Settings > Secrets to enable content evaluation."
      });
    }

    try {
      const criticalTriggers = [
        "Serious death threats or doxxing.",
        "Easy-to-replicate violent instructions.",
        "Glorification of atrocities or abuse.",
        "Promotion of self-harm, suicide, or severe eating disorders.",
        "Dangerous non-food consumption (e.g., household chemicals).",
        "High-risk unbacked medical claims contradicting expert consensus.",
        "Financial scams, phishing, or fake high-yield investment guarantees.",
        "Claims of guaranteed patterns or \"hacks\" for random games of chance."
      ];

      const promptInstructions = `
Evaluate the following text content pasted or fetched from an online asset (YouTube, social media, web, etc.) against the harmful content guidelines.

[OBJECTIVE GUIDELINES]:
Category: Harmful Content
Definition: Directly causes or encourages physical, mental, emotional, or financial harm.

The Critical Triggers you MUST evaluate and report individually:
1. "Serious death threats or doxxing."
2. "Easy-to-replicate violent instructions."
3. "Glorification of atrocities or abuse."
4. "Promotion of self-harm, suicide, or severe eating disorders."
5. "Dangerous non-food consumption (e.g., household chemicals)."
6. "High-risk unbacked medical claims contradicting expert consensus."
7. "Financial scams, phishing, or fake high-yield investment guarantees."
8. "Claims of guaranteed patterns or \"hacks\" for random games of chance."

[YOUR TASK]:
Evaluate the content objectively. Strictly avoid personal, religious, or political bias in your assessment.
For each of the 8 triggers, you must provide:
- Whether it is detected (true/false)
- Direct quote or evidence from the text supporting your detection, or empty string if not detected.
- An objective, bias-free, factual explanation detailing why this trigger was or was not hit.

Also provide:
- An overall safety status ('safe' if none of the triggers are hit or if they are discussed in a purely descriptive, educational, or critique context; 'flagged' if any are actively promoted, executed, or glorified).
- A final risk score from 0 (completely benign, academic, helpful) to 100 (instant catastrophic physical / financial harm).
- A final risk level: 'Safe' (score 0-10), 'Low' (score 11-39), 'Medium' (score 40-75), or 'High' (score 76-100).
- A summary explanation justifying the final determination objectively.
- A list of lowercase tags representing matching hazard triggers, e.g. "financial-scam" or "medical-claims".

[CONTENT TO EVALUATE]:
Title: "${title || "Untitled content"}"
Source Type: "${sourceType || "other"}"
Source URL: "${sourceUrl || "N/A"}"

CONTENT BODY:
"""
${content}
"""
`;

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: promptInstructions,
        config: {
          systemInstruction: `You are an objective auditor of online contents trained strictly on identifying Harmful, Hateful, and Deceptive content. You ignore personal beliefs, opinions, or agendas, and base your verdicts solely on literal compliance triggers. Always respond with valid JSON matching the exact schema requirements.`,
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              status: {
                type: Type.STRING,
                description: "Must be 'safe' or 'flagged'."
              },
              riskScore: {
                type: Type.INTEGER,
                description: "Risk score from 0 to 100."
              },
              riskLevel: {
                type: Type.STRING,
                description: "Must be 'Safe', 'Low', 'Medium', or 'High'."
              },
              summary: {
                type: Type.STRING,
                description: "Detailed summary explanation of the danger assessment based strictly on provided guidelines."
              },
              tags: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
                description: "Safety tags representing detected toxic attributes (e.g. ['doxxing', 'gambling-hacks'])."
              },
              triggers: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    trigger: { type: Type.STRING, description: "One of the 8 exact trigger sentences check listed." },
                    detected: { type: Type.BOOLEAN, description: "Whether it is detected." },
                    evidence: { type: Type.STRING, description: "Exact quote or line from content proving exposure, empty string if false." },
                    explanation: { type: Type.STRING, description: "Objective justification for why it's flagged or healthy." }
                  },
                  required: ["trigger", "detected", "evidence", "explanation"]
                }
              }
            },
            required: ["status", "riskScore", "riskLevel", "summary", "tags", "triggers"]
          }
        }
      });

      const textOutput = response.text;
      if (!textOutput) {
        throw new Error("Empty response returned from Gemini API");
      }

      const cleanJson = JSON.parse(textOutput.trim());
      return res.json(cleanJson);
    } catch (err: any) {
      console.error("Gemini Evaluation error:", err);
      return res.status(500).json({
        error: `Failed to evaluate safety: ${err.message || "Unknown GenAI provider failure"}`
      });
    }
  });

  // Serve Vite assets in Development vs Production
  if (process.env.NODE_ENV !== "production") {
    console.log("Setting up Vite development middleware...");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    console.log("Serving build assets statically in production mode...");
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Content Safety Evaluator server listening on port ${PORT}`);
  });
}

startServer().catch((err) => {
  console.error("Fatal server startup error:", err);
});
