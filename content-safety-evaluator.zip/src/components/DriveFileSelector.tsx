import React, { useState, useEffect } from "react";
import { X, Search, FileText, Loader2, RefreshCw, AlertCircle, HardDrive, Filter } from "lucide-react";
import { listDriveFiles, getDriveFileContent, DriveFile } from "../lib/googleDrive";

interface DriveFileSelectorProps {
  isOpen: boolean;
  onClose: () => void;
  token: string;
  onFileSelected: (title: string, content: string) => void;
}

export default function DriveFileSelector({
  isOpen,
  onClose,
  token,
  onFileSelected
}: DriveFileSelectorProps) {
  const [files, setFiles] = useState<DriveFile[]>([]);
  const [loading, setLoading] = useState(false);
  const [downloadingFileId, setDownloadingFileId] = useState<string | null>(null);
  const [error, setError] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [mimeFilter, setMimeFilter] = useState<"all" | "docs" | "text">("all");

  const fetchFiles = async () => {
    if (!token) return;
    setLoading(true);
    setError("");
    try {
      const driveFiles = await listDriveFiles(token);
      setFiles(driveFiles);
    } catch (err: any) {
      console.error(err);
      setError(err?.message || "Failed to load files from Google Drive. Please ensure the OAuth scopes are accepted.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen && token) {
      fetchFiles();
    }
  }, [isOpen, token]);

  if (!isOpen) return null;

  // Filter logic
  const filteredFiles = files.filter((file) => {
    // Search criteria
    const matchesSearch = file.name.toLowerCase().includes(searchQuery.toLowerCase());
    
    // MimeType filter criteria
    if (!matchesSearch) return false;
    if (mimeFilter === "docs") {
      return file.mimeType === "application/vnd.google-apps.document";
    }
    if (mimeFilter === "text") {
      return (
        file.mimeType.startsWith("text/") || 
        file.name.endsWith(".txt") || 
        file.name.endsWith(".md") || 
        file.name.endsWith(".json")
      );
    }
    return true;
  });

  const handleSelectFile = async (file: DriveFile) => {
    setError("");
    setDownloadingFileId(file.id);
    try {
      const content = await getDriveFileContent(file.id, file.mimeType, token);
      if (!content || !content.trim()) {
        throw new Error("The file contents are empty or could not be processed as text.");
      }
      onFileSelected(file.name, content);
      onClose();
    } catch (err: any) {
      console.error(err);
      setError(err?.message || "Failed to download and parse file content.");
    } finally {
      setDownloadingFileId(null);
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-fade-in" id="drive-modal-overlay">
      <div className="bg-[#0D0D0F] border border-slate-850 rounded-xl w-full max-w-2xl overflow-hidden shadow-2xl flex flex-col max-h-[85vh]" id="drive-modal-content">
        
        {/* Header */}
        <div className="p-5 border-b border-slate-850 flex items-center justify-between bg-[#0F0F11]">
          <div className="flex items-center gap-2.5">
            <div className="p-1.5 bg-blue-950/40 text-blue-400 rounded border border-blue-900/30">
              <HardDrive className="h-5 w-5" />
            </div>
            <div>
              <h3 className="font-bold text-white font-display text-sm tracking-wide">
                Import from Google Drive
              </h3>
              <p className="text-[11px] text-slate-400">
                Pick a text file or native Google Doc to run deep Trust & Safety audits.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 hover:bg-slate-800 rounded text-slate-400 hover:text-white transition cursor-pointer"
            id="btn-close-drive-modal"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Filters and Search Bar */}
        <div className="p-4 border-b border-slate-850 bg-[#0A0A0C]/50 flex flex-col sm:flex-row gap-3">
          {/* Search bar */}
          <div className="relative flex-1">
            <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-500" />
            <input
              type="text"
              placeholder="Search file name..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-2 text-xs bg-[#121215] border border-slate-800 rounded placeholder-slate-600 focus:outline-none focus:border-blue-500 text-slate-200 transition-colors"
            />
          </div>

          {/* Mime type Filters */}
          <div className="flex items-center gap-1.5 bg-[#121215] border border-slate-800 p-1 rounded">
            <button
              onClick={() => setMimeFilter("all")}
              className={`px-2.5 py-1 text-[10px] uppercase font-bold tracking-wider font-mono rounded transition-all cursor-pointer ${
                mimeFilter === "all" ? "bg-slate-800 text-slate-100" : "text-slate-500 hover:text-slate-300"
              }`}
            >
              All
            </button>
            <button
              onClick={() => setMimeFilter("docs")}
              className={`px-2.5 py-1 text-[10px] uppercase font-bold tracking-wider font-mono rounded transition-all cursor-pointer ${
                mimeFilter === "docs" ? "bg-slate-800 text-slate-100" : "text-slate-400 hover:text-slate-300"
              }`}
            >
              Google Docs
            </button>
            <button
              onClick={() => setMimeFilter("text")}
              className={`px-2.5 py-1 text-[10px] uppercase font-bold tracking-wider font-mono rounded transition-all cursor-pointer ${
                mimeFilter === "text" ? "bg-slate-800 text-slate-100" : "text-slate-400 hover:text-slate-300"
              }`}
            >
              Raw Text / MD
            </button>
          </div>

          {/* Reload button */}
          <button
            onClick={fetchFiles}
            disabled={loading}
            className="p-2 bg-slate-800 hover:bg-slate-700 border border-slate-700 disabled:border-slate-800 rounded text-slate-305 transition shrink-0 cursor-pointer disabled:opacity-40"
            title="Reload files from drive"
          >
            <RefreshCw className={`h-3.5 w-3.5 ${loading ? "animate-spin" : ""}`} />
          </button>
        </div>

        {/* Content Section */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          
          {error && (
            <div className="p-3.5 bg-red-950/20 border border-red-900/30 rounded-lg flex items-start gap-2 text-red-400 text-xs">
              <AlertCircle className="h-4 w-4 text-red-500 shrink-0 mt-0.5" />
              <div className="flex-1 font-sans leading-normal">
                <span className="font-bold block mb-0.5 uppercase tracking-wide font-mono text-[10px]">Permission or Load Error</span>
                <span>{error}</span>
              </div>
            </div>
          )}

          {loading ? (
            <div className="py-20 flex flex-col items-center justify-center text-center">
              <Loader2 className="h-8 w-8 animate-spin text-blue-400 mb-3" />
              <span className="text-xs font-mono text-slate-400 uppercase tracking-widest">
                Retrieving Drive File Metadata...
              </span>
            </div>
          ) : downloadingFileId ? (
            <div className="py-20 flex flex-col items-center justify-center text-center space-y-3">
              <Loader2 className="h-8 w-8 animate-spin text-emerald-400 mb-2" />
              <div className="space-y-1">
                <span className="text-xs font-bold font-mono text-slate-200 uppercase tracking-widest block">
                  Downloading Content
                </span>
                <p className="text-[11.5px] text-slate-500 max-w-xs mx-auto leading-relaxed">
                  Directly extracting the rich narrative or document contents securely from Google Server.
                </p>
              </div>
            </div>
          ) : filteredFiles.length === 0 ? (
            <div className="py-16 text-center flex flex-col items-center justify-center border border-dashed border-slate-850 rounded-xl">
              <HardDrive className="h-8 w-8 text-slate-700 mb-3" />
              <h4 className="text-xs font-mono uppercase tracking-wider text-slate-400 font-bold mb-1">
                No matching assets found
              </h4>
              <p className="text-[11px] text-slate-500 max-w-xs leading-relaxed">
                {searchQuery ? "Try searching for another filename segment." : "Add a native Google Doc, markdown document, or plain text file to your Google Drive to audit."}
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-2">
              {filteredFiles.map((file) => {
                const isDownloadingThis = downloadingFileId === file.id;
                const isGoogleDoc = file.mimeType === "application/vnd.google-apps.document";
                
                return (
                  <button
                    key={file.id}
                    onClick={() => handleSelectFile(file)}
                    disabled={downloadingFileId !== null}
                    className="w-full text-left p-3.5 bg-[#0F0F12] hover:bg-[#151519] border border-slate-850 hover:border-slate-800 disabled:opacity-40 disabled:hover:bg-[#0F0F12] rounded-xl flex items-center justify-between gap-4 transition-all group cursor-pointer"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div className={`p-2 rounded shrink-0 group-hover:scale-105 transition-all ${
                        isGoogleDoc 
                          ? "bg-blue-950/30 text-blue-400 border border-blue-900/20" 
                          : "bg-slate-900 text-slate-400 border border-slate-800"
                      }`}>
                        <FileText className="h-4 w-4" />
                      </div>
                      <div className="min-w-0">
                        <span className="font-bold text-slate-200 text-[12.5px] block truncate group-hover:text-white transition-colors">
                          {file.name}
                        </span>
                        <div className="flex items-center gap-2 mt-0.5 text-[10.5px] font-mono text-slate-500">
                          <span className="uppercase">
                            {isGoogleDoc ? "Google Doc" : "Plain Text file"}
                          </span>
                          {file.size && (
                            <>
                              <span>•</span>
                              <span>{Math.round(parseInt(file.size) / 1024)} KB</span>
                            </>
                          )}
                          {file.modifiedTime && (
                            <>
                              <span>•</span>
                              <span>Modified: {new Date(file.modifiedTime).toLocaleDateString()}</span>
                            </>
                          )}
                        </div>
                      </div>
                    </div>
                    
                    <div className="shrink-0 font-mono text-[10px] font-bold text-blue-400 bg-blue-905/10 border border-blue-900/30 px-2 py-1 rounded opacity-0 group-hover:opacity-100 group-focus:opacity-100 transition-opacity">
                      Load Asset
                    </div>
                  </button>
                );
              })}
            </div>
          )}

        </div>

        {/* Footer info/attribution */}
        <div className="p-4 border-t border-slate-850 bg-[#0A0A0C] flex items-center justify-between text-[11px] text-slate-500 font-mono">
          <span>Items loaded: {filteredFiles.length}</span>
          <span className="text-[10px] px-1.5 py-0.5 bg-blue-950/20 text-blue-400 rounded border border-blue-900/20">
            Secure OAuth Session
          </span>
        </div>

      </div>
    </div>
  );
}
