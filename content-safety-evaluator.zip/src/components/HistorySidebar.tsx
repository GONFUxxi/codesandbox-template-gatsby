import React, { useState, useRef } from "react";
import { EvaluationResult } from "../types";
import Typewriter from "./Typewriter";
import {
  Search, ShieldCheck, ShieldAlert, Trash2, Download, Upload, X,
  Calendar, Youtube, Globe, Share2, FileText, ChevronRight, AlertTriangle
} from "lucide-react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  ReferenceLine
} from "recharts";

interface HistorySidebarProps {
  history: EvaluationResult[];
  onSelectReport: (report: EvaluationResult) => void;
  onDeleteReport: (id: string) => void;
  onClearHistory: () => void;
  onImportHistory: (imported: EvaluationResult[]) => void;
  onClose: () => void;
}

export default function HistorySidebar({
  history,
  onSelectReport,
  onDeleteReport,
  onClearHistory,
  onImportHistory,
  onClose
}: HistorySidebarProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [sourceFilter, setSourceFilter] = useState<string>("all");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [showConfirmClear, setShowConfirmClear] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const getSourceIcon = (type: string) => {
    switch (type) {
      case "youtube": return <Youtube className="h-3.5 w-3.5 text-red-500" />;
      case "social_media": return <Share2 className="h-3.5 w-3.5 text-sky-400" />;
      case "web_article": return <Globe className="h-3.5 w-3.5 text-emerald-400" />;
      default: return <FileText className="h-3.5 w-3.5 text-slate-400" />;
    }
  };

  // Filtered log computations
  const filteredHistory = history.filter((item) => {
    const matchesSearch = item.title.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesSource = sourceFilter === "all" || item.sourceType === sourceFilter;
    const matchesStatus = statusFilter === "all" || item.status === statusFilter;
    return matchesSearch && matchesSource && matchesStatus;
  });

  // Sort chronologically (oldest first) to see trend over time
  const chronologicalHistory = [...filteredHistory].sort(
    (a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime()
  );

  const chartData = chronologicalHistory.map((item, idx) => ({
    name: `${idx + 1}`,
    title: item.title,
    score: item.riskScore,
    level: item.riskLevel,
  }));

  // Export full history as JSON
  const handleExportAll = () => {
    if (history.length === 0) return;
    const blob = new Blob([JSON.stringify(history, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `content-safety-audit-history-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // Import previously saved JSON
  const handleImportClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const text = event.target?.result as string;
        const parsed = JSON.parse(text);

        // Simple validation
        if (Array.isArray(parsed)) {
          const isValid = parsed.every((item) => item.id && item.title && item.status && Array.isArray(item.triggers));
          if (isValid) {
            onImportHistory(parsed);
            alert(`Parsed successfully: Imported ${parsed.length} safety logs.`);
          } else {
            alert("File contains invalid data format. Checks schema requirements.");
          }
        } else {
          alert("File must be a JSON array of evaluation results.");
        }
      } catch (err) {
        alert("Could not parse file. Verify file is valid JSON format.");
      }
    };
    reader.readAsText(file);
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  return (
    <div className="bg-[#0D0D0F] border border-slate-800 rounded-xl flex flex-col h-full overflow-hidden shadow-2xl" id="history-sidebar">
      {/* Sidebar Header details */}
      <div className="p-4 border-b border-slate-800/80 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="p-1 px-2.5 bg-slate-800 rounded text-slate-350 text-xs font-mono font-bold">
            {history.length}
          </span>
          <h3 className="font-bold text-white font-display text-xs uppercase tracking-widest">
            <Typewriter text="Audit logs history" speed={30} />
          </h3>
        </div>
        <button
          onClick={onClose}
          className="p-1.5 hover:bg-slate-800 rounded text-slate-500 hover:text-white transition-all cursor-pointer"
          id="btn-close-history"
        >
          <X className="h-4 w-4" />
        </button>
      </div>

      {/* Backup and actions bar */}
      <div className="p-3 bg-[#0A0A0B] border-b border-slate-800/80 grid grid-cols-2 gap-2 text-[10px]">
        <button
          onClick={handleExportAll}
          disabled={history.length === 0}
          className="flex items-center justify-center gap-1.5 p-2 bg-slate-800 hover:bg-slate-700 disabled:bg-slate-900 border border-slate-700 disabled:border-slate-850 disabled:text-slate-600 text-slate-250 font-bold rounded transition-all font-mono uppercase cursor-pointer"
        >
          <Download className="h-3 w-3" />
          <span>Export logs</span>
        </button>

        <button
          onClick={handleImportClick}
          className="flex items-center justify-center gap-1.5 p-2 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-250 font-bold rounded transition-all font-mono uppercase cursor-pointer"
        >
          <Upload className="h-3 w-3" />
          <span>Import backup</span>
        </button>

        <input
          type="file"
          ref={fileInputRef}
          onChange={handleFileChange}
          accept=".json"
          className="hidden"
        />
      </div>

      {/* Search and Filters */}
      <div className="p-4 border-b border-slate-800/80 space-y-3">
        <div className="relative">
          <Search className="absolute left-3 top-2.5 h-3.5 w-3.5 text-slate-500" />
          <input
            type="text"
            placeholder="Search logs by title..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3 py-2 text-xs bg-[#16161A] border border-slate-800 rounded placeholder-slate-600 text-slate-200 focus:outline-none focus:border-red-550 transition-all font-sans"
          />
        </div>

        {/* Filter categories */}
        <div className="grid grid-cols-2 gap-2 text-[9px] font-mono uppercase font-bold">
          <div className="space-y-1">
            <span className="text-slate-500 block tracking-widest text-[8px]">Source</span>
            <select
              value={sourceFilter}
              onChange={(e) => setSourceFilter(e.target.value)}
              className="w-full p-2 bg-[#16161A] border border-slate-800 rounded text-slate-300 font-mono focus:outline-none focus:border-red-550 cursor-pointer"
            >
              <option value="all">ALL SOURCES</option>
              <option value="youtube">YOUTUBE</option>
              <option value="social_media">SOCIAL</option>
              <option value="web_article">WEB SITE</option>
              <option value="other">OTHER</option>
            </select>
          </div>

          <div className="space-y-1">
            <span className="text-slate-500 block tracking-widest text-[8px]">Verdict</span>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="w-full p-2 bg-[#16161A] border border-slate-800 rounded text-slate-300 font-mono focus:outline-none focus:border-red-550 cursor-pointer"
            >
              <option value="all">ALL VERDICTS</option>
              <option value="safe">PASSED</option>
              <option value="flagged">FLAGGED</option>
            </select>
          </div>
        </div>
      </div>

      {/* Recharts safety audit risk distribution line chart */}
      {history.length > 0 && (
        <div className="p-4 border-b border-slate-800/60 bg-[#0A0A0B]/40">
          <div className="flex items-center justify-between mb-2">
            <h4 className="text-[10px] font-bold text-slate-400 font-mono uppercase tracking-widest flex items-center gap-1.5">
              <span className="h-1.5 w-1.5 bg-red-500 rounded-full animate-pulse"></span>
              Risk trend line graph
            </h4>
            <span className="text-[9px] text-slate-500 font-mono">
              {filteredHistory.length} of {history.length} shown
            </span>
          </div>

          {filteredHistory.length > 0 ? (
            <div className="h-32 w-full mt-1.5 select-none">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={chartData} margin={{ top: 5, right: 10, left: -25, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1d1d21" vertical={false} />
                  <XAxis 
                    dataKey="name" 
                    stroke="#52525b" 
                    fontSize={8} 
                    tickLine={false}
                    axisLine={{ stroke: '#27272a' }}
                  />
                  <YAxis 
                    domain={[0, 100]} 
                    stroke="#52525b" 
                    fontSize={8} 
                    tickLine={false}
                    axisLine={{ stroke: '#27272a' }}
                    ticks={[0, 25, 50, 75, 100]}
                  />
                  <Tooltip
                    content={({ active, payload }) => {
                      if (active && payload && payload.length) {
                        const data = payload[0].payload;
                        let valColor = "text-emerald-400";
                        if (data.level === "Low") valColor = "text-blue-400";
                        if (data.level === "Medium") valColor = "text-amber-400";
                        if (data.level === "High") valColor = "text-red-400";

                        return (
                          <div className="bg-[#09090a] border border-slate-800 p-2.5 rounded shadow-2xl text-[10px] font-mono leading-relaxed space-y-1 z-50">
                            <p className="text-slate-300 font-bold truncate max-w-[140px] border-b border-slate-800 pb-0.5">{data.title}</p>
                            <p className="text-slate-450">Risk score: <span className="font-extrabold text-[#fff]">{data.score}%</span></p>
                            <p className="text-slate-450">Risk level: <span className={`font-extrabold ${valColor}`}>{data.level}</span></p>
                          </div>
                        );
                      }
                      return null;
                    }}
                    cursor={{ stroke: '#27272a', strokeWidth: 1 }}
                  />
                  <ReferenceLine y={25} stroke="#10b981" strokeDasharray="3 3" strokeOpacity={0.15} />
                  <ReferenceLine y={50} stroke="#3b82f6" strokeDasharray="3 3" strokeOpacity={0.15} />
                  <ReferenceLine y={75} stroke="#f59e0b" strokeDasharray="3 3" strokeOpacity={0.15} />
                  <Line
                    type="monotone"
                    dataKey="score"
                    stroke="#ff0055"
                    strokeWidth={2}
                    activeDot={{ r: 4, stroke: '#00ffcc', strokeWidth: 1, fill: '#0d0d0f' }}
                    dot={{ r: 1.5, stroke: '#ff0055', strokeWidth: 1, fill: '#111' }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          ) : (
            <div className="py-6 text-center text-slate-600 font-mono text-[9px] uppercase tracking-widest bg-slate-950/20 rounded border border-slate-900/40">
              No index trends to render
            </div>
          )}

          <div className="flex items-center justify-between mt-2.5 text-[8px] font-extrabold font-mono text-center border-t border-slate-800/40 pt-2 tracking-wider">
            <span className="text-emerald-400/80">● SAFE (0-25)</span>
            <span className="text-blue-400/80">● LOW (26-50)</span>
            <span className="text-amber-400/80">● MED (51-75)</span>
            <span className="text-red-400/80">● HIGH (76-100)</span>
          </div>
        </div>
      )}

      {/* Audit list logs container */}
      <div className="flex-1 overflow-y-auto divide-y divide-slate-850 bg-[#0F0F11]">
        {filteredHistory.length === 0 ? (
          <div className="p-8 text-center space-y-2.5 text-slate-500">
            <Calendar className="h-6 w-6 mx-auto text-slate-600" />
            <p className="text-xs font-semibold">No history logs match filters</p>
          </div>
        ) : (
          filteredHistory.map((item) => (
            <div
              key={item.id}
              className="p-3.5 hover:bg-slate-900/40 transition-all flex items-start justify-between gap-2.5 group relative border-b border-slate-900"
            >
              <div
                onClick={() => onSelectReport(item)}
                className="flex-1 cursor-pointer min-w-0 space-y-1.5"
              >
                <div className="flex items-center gap-1.5">
                  <span className="shrink-0">{getSourceIcon(item.sourceType)}</span>
                  <span className="text-[10px] text-slate-500 font-mono">
                    {new Date(item.timestamp).toLocaleDateString()}
                  </span>
                  <span className={`ml-auto text-[8px] font-extrabold font-mono tracking-widest px-1.5 py-0.5 rounded uppercase border ${
                    item.status === 'safe'
                      ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/20"
                      : "bg-red-500/10 text-red-500 border-red-500/20"
                  }`}>
                    {item.status === 'safe' ? 'Pass' : 'Flagged'}
                  </span>
                </div>
                <h4 className="text-xs font-bold text-slate-200 truncate leading-snug pr-6 group-hover:text-red-400 transition-colors font-sans">
                  {item.title}
                </h4>
                <p className="text-[9px] text-slate-400 truncate font-mono">
                  Score: <span className="text-white font-bold">{item.riskScore}%</span> ({item.riskLevel})
                </p>
              </div>

              {/* Hover delete button */}
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onDeleteReport(item.id);
                }}
                className="p-1.5 hover:text-red-400 hover:bg-red-950/30 text-rose-500/70 hover:text-red-400 sm:opacity-50 group-hover:opacity-100 focus:opacity-100 rounded transition-all shrink-0 cursor-pointer"
                title="Delete evaluation"
              >
                <Trash2 className="h-4 w-4" />
              </button>
            </div>
          ))
        )}
      </div>

      {/* Wipe/Clear footer option */}
      {history.length > 0 && (
        <div className="p-3 bg-[#0A0A0B] border-t border-slate-800">
          {showConfirmClear ? (
            <div className="space-y-1.5">
              <span className="text-[9px] text-red-400 font-bold font-mono block text-center uppercase tracking-widest">
                ¿Borrar todo el historial? / Wipe ALL data?
              </span>
              <div className="grid grid-cols-2 gap-2 text-[9px] font-mono">
                <button
                  onClick={() => {
                    onClearHistory();
                    setShowConfirmClear(false);
                  }}
                  className="p-1.5 bg-red-600 hover:bg-red-500 text-white font-bold rounded uppercase tracking-wider cursor-pointer"
                >
                  Sí, Borrar todo / Delete All
                </button>
                <button
                  onClick={() => setShowConfirmClear(false)}
                  className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 font-bold rounded uppercase tracking-wider cursor-pointer"
                >
                  Cancelar / Cancel
                </button>
              </div>
            </div>
          ) : (
            <button
              onClick={() => setShowConfirmClear(true)}
              className="w-full flex items-center justify-center gap-1.5 p-2 bg-red-950/20 hover:bg-red-900/30 text-red-400 border border-red-900/30 font-bold rounded transition-all font-mono text-[9px] uppercase tracking-widest cursor-pointer"
            >
              <Trash2 className="h-3 w-3" />
              <span>BORRAR TODO EL HISTORIAL / CLEAR ALL</span>
            </button>
          )}
        </div>
      )}
    </div>
  );
}
