import React, { useEffect, useRef } from "react";

export default function MatrixBackground() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    // Set canvas dimensions
    const resizeCanvas = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    resizeCanvas();
    window.addEventListener("resize", resizeCanvas);

    // Classical Matrix-themed & Safety audit Chinese characters
    const charString = "中華人民共和國安全漏洞評估人工智能信任矩陣網絡信道分析檢測和防禦系統德義禮智信和平成就未來網絡數據保護防線";
    const chars = charString.split("");

    const fontSize = 14;
    let columns = Math.floor(canvas.width / fontSize);
    let drops: number[] = Array(columns)
      .fill(1)
      .map(() => Math.floor(Math.random() * -120));

    // Monitor resize adjustments
    const checkColumns = () => {
      const currentColumns = Math.floor(canvas.width / fontSize);
      if (currentColumns > drops.length) {
        const extra = currentColumns - drops.length;
        for (let i = 0; i < extra; i++) {
          drops.push(Math.floor(Math.random() * -120));
        }
      }
      columns = currentColumns;
    };

    let animationFrameId: number;

    const draw = () => {
      // Semi-transparent overlay to create smooth trail fades (tuned with dark palette)
      ctx.fillStyle = "rgba(10, 10, 11, 0.16)";
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      ctx.font = `${fontSize}px monospace`;

      checkColumns();

      for (let i = 0; i < columns; i++) {
        // Offset starting times
        if (drops[i] < 0) {
          drops[i]++;
          continue;
        }

        const text = chars[Math.floor(Math.random() * chars.length)];
        const x = i * fontSize;
        const y = drops[i] * fontSize;

        const isLeading = Math.random() > 0.98;

        if (isLeading) {
          // Neon leader drop (whitish-green glowing hot tip)
          ctx.fillStyle = "#d1ffd6";
          ctx.shadowColor = "#39ff14";
          ctx.shadowBlur = 12;
        } else {
          // Standard layered green neon
          const opacityRange = Math.random() * 0.5 + 0.5;
          ctx.fillStyle = `rgba(0, 255, 102, ${opacityRange})`;
          ctx.shadowColor = "#00ff66";
          ctx.shadowBlur = 6;
        }

        ctx.fillText(text, x, y);
        // Clear shadow settings to optimize draw efficiency
        ctx.shadowBlur = 0;

        // Reset drops when offscreen with a randomized chance to space them out
        if (y > canvas.height && Math.random() > 0.98) {
          drops[i] = 0;
        } else {
          drops[i]++;
        }
      }

      animationFrameId = requestAnimationFrame(draw);
    };

    // Begin render loop
    draw();

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener("resize", resizeCanvas);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 w-full h-full pointer-events-none -z-50 opacity-[0.52]"
      id="matrix-rain-background"
    />
  );
}
