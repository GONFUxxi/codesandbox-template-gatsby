import React from "react";
import { AlertCircle, Shield, CheckCircle, Info, X } from "lucide-react";
import { OBJECTIVE_GUIDELINES } from "../types";
import Typewriter from "./Typewriter";

interface GuidelinesPanelProps {
  onClose: () => void;
}

export default function GuidelinesPanel({ onClose }: GuidelinesPanelProps) {
  const framework = OBJECTIVE_GUIDELINES.classification_framework;

  return (
    <div className="bg-[#0D0D0F] border border-slate-800 rounded-xl p-6 shadow-2xl relative overflow-hidden" id="guidelines-card">
      <div className="flex items-start justify-between mb-5">
        <div className="flex items-center gap-2.5">
          <div className="p-1.5 bg-slate-850 text-blue-400 rounded">
            <Shield className="h-5 w-5" />
          </div>
          <h3 className="text-base font-bold text-white font-display">
            <Typewriter text="Active Evaluation Framework" speed={30} />
          </h3>
        </div>
        <button
          onClick={onClose}
          className="p-1.5 text-slate-500 hover:text-white hover:bg-slate-800 rounded transition-all cursor-pointer"
          aria-label="Close panel"
          id="btn-close-guidelines"
        >
          <X className="h-4 w-4" strokeWidth={2} />
        </button>
      </div>

      <div className="space-y-6 text-sm">
        <div>
          <span className="text-[10px] font-semibold tracking-wider font-mono uppercase text-slate-500 block mb-1">
            Skill &amp; Scope
          </span>
          <p className="text-sm font-semibold text-slate-300">
            {OBJECTIVE_GUIDELINES.skill}
          </p>
        </div>

        <div className="p-4 bg-[#16161A] border border-slate-800/80 rounded">
          <span className="text-[10px] font-semibold tracking-wider font-mono uppercase text-slate-500 block mb-1">
            Auditing Purpose statement
          </span>
          <p className="text-slate-400 text-xs leading-relaxed">
            {OBJECTIVE_GUIDELINES.purpose}
          </p>
        </div>

        <div className="space-y-3">
          <span className="text-[10px] font-semibold tracking-wider font-mono uppercase text-slate-500 block">
            Category Definitions: {framework.category}
          </span>
          <div className="flex items-start gap-3 p-3.5 bg-red-950/20 rounded border border-red-900/30">
            <AlertCircle className="h-4 w-4 text-red-500 mt-0.5 shrink-0" />
            <div className="text-xs">
              <strong className="text-red-400 block mb-0.5 font-bold uppercase tracking-wider font-mono">Harmful Content definition:</strong>
              <span className="text-slate-300 leading-relaxed">{framework.definition}</span>
            </div>
          </div>
        </div>

        <div className="space-y-2.5">
          <span className="text-[10px] font-semibold tracking-wider font-mono uppercase text-slate-500 block">
            The 8 Critical Flag Triggers Checklist:
          </span>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
            {framework.critical_triggers.map((trigger, i) => (
              <div
                key={i}
                className="flex items-start gap-2.5 p-3 rounded bg-[#16161A] hover:bg-slate-900/50 transition-colors border border-slate-850"
              >
                <div className="h-5 w-5 bg-slate-800 rounded flex items-center justify-center font-mono text-[10px] text-slate-300 shrink-0 mt-0.5 font-bold">
                  {i + 1}
                </div>
                <p className="text-xs text-slate-300 leading-normal font-medium">
                  {trigger}
                </p>
              </div>
            ))}
          </div>
        </div>

        <div className="p-3.5 bg-amber-95/10 border border-amber-900/30 rounded text-xs text-amber-400 leading-relaxed flex gap-2.5 items-start bg-amber-950/10">
          <Info className="h-4 w-4 shrink-0 text-amber-500 mt-0.5" />
          <div>
            <span className="font-bold uppercase tracking-wider font-mono text-[10px] block mb-0.5">Observer Disclaimer</span>
            Assessments are powered by server-side GenAI models trained strictly to act as neutral policy observers. It checks literal transcript compliance, avoiding religious bias, personal beliefs, or subjective political assumptions.
          </div>
        </div>
      </div>
    </div>
  );
}
