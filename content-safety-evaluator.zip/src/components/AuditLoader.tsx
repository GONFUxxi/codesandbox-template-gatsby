import React, { useState, useEffect } from "react";
import { ShieldAlert, Loader2, Search, HeartPulse, Scale, ShieldCheck } from "lucide-react";

export default function AuditLoader() {
  const steps = [
    { text: "Reading raw transcript elements and text paragraphs...", icon: <Search className="h-5 w-5 text-red-400 animate-pulse" /> },
    { text: "Scanning text vectors for serious threats or doxxing indicators...", icon: <ShieldAlert className="h-5 w-5 text-red-500 animate-pulse" /> },
    { text: "Cross-referencing medical claims with clinical consensus guidelines...", icon: <HeartPulse className="h-5 w-5 text-rose-400 animate-bounce" /> },
    { text: "Checking high-yield financial structures or gambling loopholes...", icon: <Scale className="h-5 w-5 text-amber-500" /> },
    { text: "Verifying glorifications of self-harm or eating disorders...", icon: <ShieldCheck className="h-5 w-5 text-emerald-400" /> },
    { text: "Validating safe and unsafe patterns via Gemini policy filters...", icon: <Loader2 className="h-5 w-5 text-slate-400 animate-spin" /> }
  ];

  const [currentStepIndex, setCurrentStepIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentStepIndex((prev) => (prev + 1) % steps.length);
    }, 2800);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="border-loader-container active shadow-2xl">
      <div className="border-loader-overlay p-8 flex flex-col items-center justify-center min-h-[350px] space-y-6" id="audit-loader">
        <div className="relative flex items-center justify-center">
          <div className="absolute h-16 w-16 bg-red-650/10 rounded-full animate-ping"></div>
          <div className="h-20 w-20 bg-red-950/20 border border-red-900/30 rounded flex items-center justify-center text-red-400 relative shadow-2xl">
            <Loader2 className="h-10 w-10 animate-spin stroke-[2]" />
          </div>
        </div>

        <div className="text-center space-y-2 max-w-sm">
          <h4 className="text-xs font-bold text-slate-350 font-mono uppercase tracking-widest">
            Trust &amp; Safety Pipeline
          </h4>
          <p className="text-[11px] text-slate-400 font-normal leading-relaxed">
            Running deep check on pasted metadata based on direct classification trigger criteria.
          </p>
        </div>

        <div className="w-full max-w-sm p-4 bg-[#16161A] border border-slate-800/60 rounded flex items-center gap-3.5 transition-all duration-300">
          <div className="shrink-0">{steps[currentStepIndex].icon}</div>
          <span className="text-xs font-medium text-slate-200 leading-snug">
            {steps[currentStepIndex].text}
          </span>
        </div>
      </div>
    </div>
  );
}
