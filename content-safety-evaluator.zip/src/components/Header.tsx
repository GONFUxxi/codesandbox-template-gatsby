import React from "react";
import { ShieldCheck, HelpCircle, History } from "lucide-react";
import Typewriter from "./Typewriter";

interface HeaderProps {
  onShowGuidelines: () => void;
  onShowHistory: () => void;
  showHistoryBadge: number;
}

export default function Header({ onShowGuidelines, onShowHistory, showHistoryBadge }: HeaderProps) {
  return (
    <header className="border-b border-slate-850 bg-[#0F0F11] sticky top-0 z-40 w-full" id="app-header">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-red-650 text-white rounded">
            <ShieldCheck className="h-5 w-5 stroke-[2]" />
          </div>
          <div>
            <span className="text-[10px] font-semibold tracking-wider text-slate-500 uppercase font-mono block">
              Trust &amp; Safety Auditor
            </span>
            <h1 className="text-lg font-bold tracking-tight text-white font-display">
              <Typewriter text="SafeGuard " speed={55} />
              <Typewriter text="Analyzer v1.0" speed={55} delay={550} className="text-slate-400 font-normal text-sm underline decoration-slate-800 underline-offset-4" />
            </h1>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onShowGuidelines}
            className="flex items-center gap-2 px-3.5 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white border border-slate-700 transition-all text-xs font-semibold uppercase tracking-wider font-mono cursor-pointer"
            title="Read Evaluation Framework Prompt"
            id="btn-show-guidelines"
          >
            <HelpCircle className="h-3.5 w-3.5 text-blue-400" />
            <span className="hidden sm:inline">Guidelines</span>
          </button>

          <button
            onClick={onShowHistory}
            className="relative flex items-center gap-2 px-3.5 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white border border-slate-700 transition-all text-xs font-semibold uppercase tracking-wider font-mono cursor-pointer"
            title="View Past Audits"
            id="btn-show-history"
          >
            <History className="h-3.5 w-3.5 text-emerald-400" />
            <span>Audited Logs</span>
            {showHistoryBadge > 0 && (
              <span className="absolute -top-1.5 -right-1 flex h-4 min-w-[16px] items-center justify-center rounded bg-red-600 px-1 text-[9px] font-extrabold text-white leading-none">
                {showHistoryBadge}
              </span>
            )}
          </button>
        </div>
      </div>
    </header>
  );
}
