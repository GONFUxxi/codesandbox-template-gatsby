import React from "react";
import { Facebook, Twitter, Instagram, Linkedin, Youtube, ExternalLink } from "lucide-react";

interface GlowingSocialIconsProps {
  embedded?: boolean;
}

export default function GlowingSocialIcons({ embedded = false }: GlowingSocialIconsProps) {
  const socialLinks = [
    {
      name: "Facebook",
      class: "facebook",
      icon: <Facebook className="h-5 w-5 fill-current" />,
      url: "https://facebook.com",
    },
    {
      name: "Twitter",
      class: "twitter",
      icon: <Twitter className="h-5 w-5 fill-current" />,
      url: "https://twitter.com",
    },
    {
      name: "Instagram",
      class: "instagram",
      icon: <Instagram className="h-5 w-5" />,
      url: "https://instagram.com",
    },
    {
      name: "LinkedIn",
      class: "linkedin",
      icon: <Linkedin className="h-5 w-5 fill-current" />,
      url: "https://linkedin.com",
    },
    {
      name: "YouTube",
      class: "youtube",
      icon: <Youtube className="h-5 w-5 fill-current" />,
      url: "https://youtube.com",
    },
  ];

  if (embedded) {
    return (
      <div className="bg-[#131317]/55 border border-slate-850/60 rounded-xl p-4 text-center space-y-3.5" id="glowing-social-widget-embedded">
        <div className="flex items-center justify-between px-2">
          <span className="text-[10px] font-bold font-mono uppercase tracking-widest text-emerald-400">
            Active Media Auditing Ports
          </span>
          <span className="text-[10px] text-slate-500 font-mono">
            Direct channels
          </span>
        </div>

        <ul className="glowing-social-list">
          {socialLinks.map((social) => (
            <li
              key={social.name}
              className={social.class}
              onClick={() => window.open(social.url, "_blank", "noreferrer")}
              title={`Verify / Check active feed on ${social.name}`}
            >
              {social.icon}
            </li>
          ))}
        </ul>
      </div>
    );
  }

  return (
    <div className="bg-[#0F0F11]/90 border border-slate-850 rounded-xl p-5 shadow-xl text-center space-y-4" id="glowing-social-widget">
      <div className="space-y-1">
        <span className="text-[10px] font-bold font-mono uppercase tracking-widest text-emerald-400 block">
          Community Hub &amp; Media Links
        </span>
        <h4 className="text-xs font-bold font-mono text-slate-300 uppercase">
          Glowing Social Channels
        </h4>
      </div>

      <ul className="glowing-social-list">
        {socialLinks.map((social) => (
          <li
            key={social.name}
            className={social.class}
            onClick={() => window.open(social.url, "_blank", "noreferrer")}
            title={`Follow on ${social.name}`}
          >
            {social.icon}
          </li>
        ))}
      </ul>

      <p className="text-[10px] text-slate-500 font-mono">
        Interlink your safety audits across active channels
      </p>
    </div>
  );
}
