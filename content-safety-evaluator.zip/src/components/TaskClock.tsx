import React, { useState, useEffect, useRef } from "react";
import Typewriter from "./Typewriter";
import {
  Clock, Play, Pause, RotateCcw, Hourglass, CheckCircle2, ChevronDown, ChevronUp,
  ShieldAlert, Sparkles, Coffee, Timer, ListTodo, Plus, Trash2
} from "lucide-react";

interface CompletedSession {
  id: string;
  taskName: string;
  durationMinutes: number;
  completedAt: string;
  mode: string;
}

const DEFAULT_TASKS = [
  "Social Media Misinfo Investigation",
  "Web Article Deception Audit",
  "Financial Threat Content Check",
  "Political Rhetoric Review",
  "Platform Policy Compliance Verification"
];

export default function TaskClock() {
  const [isExpanded, setIsExpanded] = useState(true);
  
  // Timer States
  const [timerMode, setTimerMode] = useState<"countdown" | "stopwatch">("countdown");
  const [countdownPreset, setCountdownPreset] = useState<number>(25 * 60); // default 25 mins in seconds
  const [timeLeft, setTimeLeft] = useState<number>(25 * 60);
  const [stopwatchSeconds, setStopwatchSeconds] = useState<number>(0);
  const [isRunning, setIsRunning] = useState<boolean>(false);

  // Active Task Scope
  const [tasks, setTasks] = useState<string[]>(() => {
    const saved = localStorage.getItem("safeguard_audit_tasks");
    return saved ? JSON.parse(saved) : DEFAULT_TASKS;
  });
  const [selectedTask, setSelectedTask] = useState<string>(tasks[0] || "");
  const [newTaskInput, setNewTaskInput] = useState("");
  const [showTaskForm, setShowTaskForm] = useState(false);

  // Audit focus summary session completions
  const [completedSessions, setCompletedSessions] = useState<CompletedSession[]>(() => {
    const saved = localStorage.getItem("safeguard_completed_sessions");
    return saved ? JSON.parse(saved) : [];
  });

  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  // Sync state to localstorage
  useEffect(() => {
    localStorage.setItem("safeguard_audit_tasks", JSON.stringify(tasks));
  }, [tasks]);

  useEffect(() => {
    localStorage.setItem("safeguard_completed_sessions", JSON.stringify(completedSessions));
  }, [completedSessions]);

  // Handle timer ticks
  useEffect(() => {
    if (isRunning) {
      intervalRef.current = setInterval(() => {
        if (timerMode === "countdown") {
          setTimeLeft((prev) => {
            if (prev <= 1) {
              handleTimerComplete();
              return 0;
            }
            return prev - 1;
          });
        } else {
          setStopwatchSeconds((prev) => prev + 1);
        }
      }, 1000);
    } else {
      if (intervalRef.current) clearInterval(intervalRef.current);
    }

    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [isRunning, timerMode]);

  const handleTimerComplete = () => {
    setIsRunning(false);
    if (intervalRef.current) clearInterval(intervalRef.current);

    // Save automatic logged completed session
    const durationMin = Math.round(countdownPreset / 60);
    const newSession: CompletedSession = {
      id: Math.random().toString(36).substring(2, 9),
      taskName: selectedTask || "General Security Audit",
      durationMinutes: durationMin,
      completedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      mode: "Countdown Sprint"
    };

    setCompletedSessions((prev) => [newSession, ...prev]);

    // Simple audio cue wrapper if supported
    try {
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.type = "sine";
      osc.frequency.setValueAtTime(880, audioCtx.currentTime); // A5 note
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      gain.gain.setValueAtTime(0.15, audioCtx.currentTime);
      osc.start();
      osc.stop(audioCtx.currentTime + 0.35);
    } catch (e) {
      // Audio context failure gracefully caught
    }
  };

  const handleTogglePlay = () => {
    setIsRunning(!isRunning);
  };

  const handleReset = () => {
    setIsRunning(false);
    if (timerMode === "countdown") {
      setTimeLeft(countdownPreset);
    } else {
      setStopwatchSeconds(0);
    }
  };

  const handleSetPreset = (minutes: number) => {
    setIsRunning(false);
    setTimerMode("countdown");
    const seconds = minutes * 60;
    setCountdownPreset(seconds);
    setTimeLeft(seconds);
  };

  const handleSwitchToStopwatch = () => {
    setIsRunning(false);
    setTimerMode("stopwatch");
    setStopwatchSeconds(0);
  };

  const handleAddTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTaskInput.trim()) return;
    const updated = [...tasks, newTaskInput.trim()];
    setTasks(updated);
    setSelectedTask(newTaskInput.trim());
    setNewTaskInput("");
    setShowTaskForm(false);
  };

  const handleDeleteTask = (taskToDelete: string) => {
    const updated = tasks.filter(t => t !== taskToDelete);
    setTasks(updated);
    if (selectedTask === taskToDelete) {
      setSelectedTask(updated[0] || "");
    }
  };

  const handleLogManualSession = () => {
    if (timerMode === "stopwatch" && stopwatchSeconds > 5) {
      // log currently elapsed stopwatch time
      const minsRounded = Math.max(1, Math.round(stopwatchSeconds / 60));
      const newSession: CompletedSession = {
        id: Math.random().toString(36).substring(2, 9),
        taskName: selectedTask || "General Security Audit",
        durationMinutes: minsRounded,
        completedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        mode: "Manual Logged Stopwatch"
      };
      setCompletedSessions((prev) => [newSession, ...prev]);
      setStopwatchSeconds(0);
      setIsRunning(false);
    }
  };

  const handleClearLogs = () => {
    setCompletedSessions([]);
  };

  // Formatting helpers
  const formatTime = (totalSecs: number) => {
    const hrs = Math.floor(totalSecs / 3600);
    const mins = Math.floor((totalSecs % 3600) / 60);
    const secs = totalSecs % 60;

    const pad = (n: number) => n.toString().padStart(2, "0");

    if (hrs > 0) {
      return `${pad(hrs)}:${pad(mins)}:${pad(secs)}`;
    }
    return `${pad(mins)}:${pad(secs)}`;
  };

  // Radial progress loader for static rendering
  const activeTime = timerMode === "countdown" ? timeLeft : stopwatchSeconds;
  const totalBaseTime = timerMode === "countdown" ? countdownPreset : 3600; // arbitrary reference for stopwatch
  const progressRatio = Math.min(1, activeTime / (totalBaseTime || 1));

  return (
    <div
      className="bg-[#0F0F11] border border-slate-850 rounded-xl overflow-hidden shadow-2xl transition-all duration-300"
      id="task-clock-widget"
    >
      {/* Header bar controls */}
      <div className="px-4 py-3 bg-[#131317] border-b border-slate-850 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping shrink-0" />
          <h3 className="text-xs font-bold font-mono uppercase tracking-widest text-slate-200 flex items-center gap-1.5">
            <Timer className="h-3.5 w-3.5 text-emerald-400" />
            <Typewriter text="Active Investigation Clock" speed={25} />
          </h3>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-[10px] text-slate-500 font-mono font-bold bg-[#0A0A0C] px-2 py-0.5 rounded border border-slate-900">
            {timerMode === "countdown" ? "Focus Sprint" : "Elapsed Time"}
          </span>
          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="text-slate-400 hover:text-white p-1 rounded bg-slate-900/60 hover:bg-slate-800 transition cursor-pointer"
            id="btn-toggle-clock-expand"
          >
            {isExpanded ? <ChevronUp className="h-3.5 w-3.5" /> : <ChevronDown className="h-3.5 w-3.5" />}
          </button>
        </div>
      </div>

      {isExpanded && (
        <div className="p-4 sm:p-5 space-y-4">
          {/* Main layout clock display side-by-side components */}
          <div className="grid grid-cols-1 md:grid-cols-12 gap-5 items-center">
            
            {/* Clock Circle display & Controls */}
            <div className="col-span-1 md:col-span-5 flex flex-col items-center justify-center py-2 border-r border-slate-850/40 md:pr-4">
              <div className="relative h-28 w-28 flex items-center justify-center rounded-full bg-[#070709] border-4 border-slate-900 shadow-inner group">
                {/* Visual Neon radial arc */}
                <div 
                  className="absolute inset-[-4px] rounded-full border-4 border-transparent transition-all"
                  style={{
                    borderColor: isRunning ? "transparent #10b981 #10b981 transparent" : "transparent #3b82f6 #3b82f6 transparent",
                    transform: `rotate(${progressRatio * 360}deg)`,
                    opacity: 0.6
                  }}
                />
                
                {/* Time values rendering */}
                <div className="text-center z-10">
                  <span className="text-2xl font-extrabold font-mono text-white tracking-tight leading-none block">
                    {formatTime(activeTime)}
                  </span>
                  <span className="text-[8px] font-bold text-slate-500 uppercase tracking-widest font-mono mt-1 block">
                    {isRunning ? "Audit Live" : "Paused"}
                  </span>
                </div>
              </div>

              {/* Action play controllers */}
              <div className="flex items-center gap-2.5 mt-4">
                <button
                  onClick={handleTogglePlay}
                  className={`p-2.5 rounded-full transition-all duration-200 cursor-pointer ${
                    isRunning 
                      ? "bg-amber-650 hover:bg-amber-550 border border-amber-700 text-white" 
                      : "bg-[#16a34a] hover:bg-[#15803d] border border-green-700 text-white"
                  }`}
                  id="btn-clock-play"
                  title={isRunning ? "Pause Session" : "Start Focus Timer"}
                >
                  {isRunning ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4 fill-white" />}
                </button>

                <button
                  onClick={handleReset}
                  className="p-2.5 rounded-full bg-[#1e293b] hover:bg-slate-705 border border-slate-700 text-slate-300 transition cursor-pointer"
                  id="btn-clock-reset"
                  title="Reset clock state"
                >
                  <RotateCcw className="h-4 w-4" />
                </button>

                {timerMode === "stopwatch" && stopwatchSeconds > 5 && (
                  <button
                    onClick={handleLogManualSession}
                    className="p-2.5 rounded-full bg-blue-950/40 hover:bg-blue-900 border border-blue-800 text-blue-400 transition cursor-pointer text-xs"
                    id="btn-clock-log-manual"
                    title="Log session milestone"
                  >
                    <CheckCircle2 className="h-4 w-4" />
                  </button>
                )}
              </div>
            </div>

            {/* Presets and selector controls */}
            <div className="col-span-1 md:col-span-7 space-y-3">
              <div>
                <span className="text-[9px] font-semibold tracking-wider text-slate-500 uppercase font-mono block mb-1.5">
                  Investigation Sprints &amp; Timers
                </span>
                
                {/* Grid selection buttons */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  <button
                    onClick={() => handleSetPreset(10)}
                    className={`px-2 py-1.5 rounded border text-[10px] uppercase font-mono font-bold transition flex flex-col items-center justify-center gap-0.5 cursor-pointer ${
                      timerMode === "countdown" && countdownPreset === 10 * 60
                        ? "bg-red-950/20 text-red-400 border-red-900"
                        : "bg-[#0A0A0C] text-slate-400 border-slate-900 hover:border-slate-800"
                    }`}
                  >
                    <Timer className="h-3 w-3" />
                    <span>10m Quick</span>
                  </button>

                  <button
                    onClick={() => handleSetPreset(25)}
                    className={`px-2 py-1.5 rounded border text-[10px] uppercase font-mono font-bold transition flex flex-col items-center justify-center gap-0.5 cursor-pointer ${
                      timerMode === "countdown" && countdownPreset === 25 * 60
                        ? "bg-red-950/20 text-red-400 border-red-900"
                        : "bg-[#0A0A0C] text-slate-400 border-slate-900 hover:border-slate-800"
                    }`}
                  >
                    <Hourglass className="h-3 w-3" />
                    <span>25m Audit</span>
                  </button>

                  <button
                    onClick={() => handleSetPreset(45)}
                    className={`px-2 py-1.5 rounded border text-[10px] uppercase font-mono font-bold transition flex flex-col items-center justify-center gap-0.5 cursor-pointer ${
                      timerMode === "countdown" && countdownPreset === 45 * 60
                        ? "bg-red-950/20 text-red-400 border-red-900"
                        : "bg-[#0A0A0C] text-slate-400 border-slate-900 hover:border-slate-800"
                    }`}
                  >
                    <Sparkles className="h-3 w-3" />
                    <span>45m deep</span>
                  </button>

                  <button
                    onClick={handleSwitchToStopwatch}
                    className={`px-2 py-1.5 rounded border text-[10px] uppercase font-mono font-bold transition flex flex-col items-center justify-center gap-0.5 cursor-pointer ${
                      timerMode === "stopwatch"
                        ? "bg-red-950/20 text-red-400 border-red-900"
                        : "bg-[#0A0A0C] text-slate-400 border-slate-900 hover:border-slate-800"
                    }`}
                  >
                    <Clock className="h-3 w-3" />
                    <span>Stopwatch</span>
                  </button>
                </div>
              </div>

              {/* Task Tracker Connection */}
              <div className="space-y-1.5 bg-[#0A0A0C] border border-slate-900 rounded-lg p-2.5">
                <div className="flex items-center justify-between gap-2.5">
                  <span className="text-[9px] font-bold tracking-wider text-slate-500 uppercase font-mono block flex items-center gap-1">
                    <ListTodo className="h-3 w-3 text-red-500" />
                    Assigned Focus Work Task:
                  </span>
                  <button
                    type="button"
                    onClick={() => setShowTaskForm(!showTaskForm)}
                    className="text-[9.5px] font-bold font-mono text-red-400 hover:text-red-300 transition cursor-pointer"
                  >
                    {showTaskForm ? "Cancel" : "+ New"}
                  </button>
                </div>

                {showTaskForm ? (
                  <form onSubmit={handleAddTask} className="flex gap-1.5 mt-1.5">
                    <input
                      type="text"
                      className="flex-1 px-2 py-1 bg-slate-900 border border-slate-800 text-slate-200 text-xs rounded focus:outline-none focus:border-red-800"
                      placeholder="Add custom task..."
                      value={newTaskInput}
                      onChange={(e) => setNewTaskInput(e.target.value)}
                    />
                    <button
                      type="submit"
                      className="px-2.5 py-1 bg-red-650 text-white rounded text-[10px] uppercase font-mono font-bold cursor-pointer"
                    >
                      Save
                    </button>
                  </form>
                ) : (
                  <div className="flex items-center justify-between gap-2.5 mt-1">
                    {tasks.length > 0 ? (
                      <select
                        value={selectedTask}
                        onChange={(e) => setSelectedTask(e.target.value)}
                        className="bg-transparent border-none text-slate-250 text-xs rounded select-none cursor-pointer focus:outline-none focus:ring-0 max-w-[200px] font-medium truncate"
                      >
                        {tasks.map((t) => (
                          <option key={t} value={t} className="bg-slate-950 text-slate-300">
                            {t}
                          </option>
                        ))}
                      </select>
                    ) : (
                      <span className="text-slate-500 text-xs italic font-mono">No tasks - click + New</span>
                    )}

                    {selectedTask && (
                      <button
                        onClick={() => handleDeleteTask(selectedTask)}
                        className="text-slate-600 hover:text-red-400 p-0.5 rounded cursor-pointer"
                        title="Delete selected task preset"
                      >
                        <Trash2 className="h-3 w-3" />
                      </button>
                    )}
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Collapsible log trace of completed metrics */}
          {completedSessions.length > 0 && (
            <div className="border-t border-slate-850/60 pt-3 mt-1 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-[9px] font-bold text-slate-500 uppercase tracking-widest font-mono flex items-center gap-1">
                  <Coffee className="h-3.5 w-3.5 text-slate-400" />
                  Completed Focus log traces ({completedSessions.length})
                </span>
                <button
                  onClick={handleClearLogs}
                  className="text-[8px] font-bold font-mono text-slate-605 hover:text-slate-400 uppercase tracking-wider cursor-pointer"
                >
                  Clear logs
                </button>
              </div>

              <div className="max-h-24 overflow-y-auto space-y-1.5 pr-1">
                {completedSessions.map((crs) => (
                  <div
                    key={crs.id}
                    className="flex items-center justify-between gap-4 p-1.5 rounded bg-[#0A0A0C]/50 border border-slate-900/60 text-[10px] font-mono leading-tight text-slate-400"
                  >
                    <div className="flex items-center gap-1.5 truncate">
                      <span className="text-emerald-400 font-extrabold shrink-0">✓</span>
                      <p className="truncate text-slate-300" title={crs.taskName}>{crs.taskName}</p>
                    </div>
                    <div className="flex items-center gap-1.5 shrink-0 text-slate-500 text-[9px] whitespace-nowrap">
                      <span>{crs.durationMinutes}m duration</span>
                      <span>•</span>
                      <span>{crs.completedAt}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
