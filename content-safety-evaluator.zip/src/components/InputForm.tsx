import React, { useState, useEffect } from "react";
import { Youtube, Globe, FileText, Share2, HelpCircle, Loader2, HardDrive, LogOut, CheckCircle, FolderOpen, X } from "lucide-react";
import Typewriter from "./Typewriter";
import DriveFileSelector from "./DriveFileSelector";

interface InputFormProps {
  onSubmit: (data: {
    content: string;
    title: string;
    sourceType: 'youtube' | 'social_media' | 'web_article' | 'other';
    sourceUrl: string;
  }) => void;
  isLoading: boolean;
  driveUser: any | null;
  driveToken: string | null;
  onConnectDrive: () => void;
  onDisconnectDrive: () => void;
}

export default function InputForm({
  onSubmit,
  isLoading,
  driveUser,
  driveToken,
  onConnectDrive,
  onDisconnectDrive
}: InputFormProps) {
  const [sourceUrl, setSourceUrl] = useState("");
  const [content, setContent] = useState("");
  const [title, setTitle] = useState("");
  const [sourceType, setSourceType] = useState<'youtube' | 'social_media' | 'web_article' | 'other'>('web_article');
  
  const [isFetchingUrl, setIsFetchingUrl] = useState(false);
  const [fetchError, setFetchError] = useState("");
  const [fetchWarning, setFetchWarning] = useState("");
  
  // Google Drive Selector Modal state
  const [isDriveModalOpen, setIsDriveModalOpen] = useState(false);
  const [driveImportSuccess, setDriveImportSuccess] = useState("");

  // Auto-detect source platform from pasted URL
  useEffect(() => {
    if (!sourceUrl) {
      setFetchWarning("");
      setFetchError("");
      return;
    }

    try {
      const urlObj = new URL(sourceUrl);
      if (urlObj.hostname.includes("youtube.com") || urlObj.hostname.includes("youtu.be")) {
        setSourceType('youtube');
        setFetchWarning("YouTube Link detected! Click 'Fetch Video' or press 'RUN EVALUATION' to automatically retrieve the video title and get the transcript/summary using Search Grounding, or you can paste the transcript below manually.");
        setFetchError("");
      } else if (
        urlObj.hostname.includes("twitter.com") || 
        urlObj.hostname.includes("x.com") || 
        urlObj.hostname.includes("facebook.com") || 
        urlObj.hostname.includes("instagram.com") || 
        urlObj.hostname.includes("reddit.com") || 
        urlObj.hostname.includes("tiktok.com")
      ) {
        setSourceType('social_media');
        setFetchWarning("Social media posts are often gated behind logins. Safe-fetching will attempt to parse readable content. If it fails, kindly paste the text below.");
        setFetchError("");
      } else {
        setSourceType('web_article');
        setFetchWarning("");
        setFetchError("");
      }
    } catch (e) {
      // Invalid URL while user is typing
      setFetchWarning("");
    }
  }, [sourceUrl]);

  // Handle URL fetch server side
  const handleUrlFetch = async () => {
    if (!sourceUrl || isFetchingUrl) return;
    setFetchError("");
    setFetchWarning("");
    setIsFetchingUrl(true);

    try {
      const resp = await fetch("/api/fetch-url", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url: sourceUrl })
      });

      const data = await resp.json();

      if (!resp.ok) {
        throw new Error(data.error || "Internal server error");
      }

      if (data.title) {
        setTitle(data.title);
      }
      if (data.text) {
        setContent(data.text);
      }
      if (data.isYouTube) {
        setFetchWarning("YouTube metadata and content synthesized successfully! You can inspect or edit the detailed summary below, then click 'RUN EVALUATION'.");
      }
    } catch (err: any) {
      setFetchError(err.message || "Failed to contact URL extraction server.");
    } finally {
      setIsFetchingUrl(false);
    }
  };

  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // If content is empty but they typed a URL, do the fetch automatically!
    if (!content.trim() && sourceUrl.trim()) {
      setFetchError("");
      setFetchWarning("");
      setIsFetchingUrl(true);
      try {
        const resp = await fetch("/api/fetch-url", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ url: sourceUrl })
        });

        const data = await resp.json();

        if (!resp.ok) {
          throw new Error(data.error || "Internal server error");
        }

        let finalTitle = title;
        let finalContent = "";

        if (data.title) {
          setTitle(data.title);
          finalTitle = data.title;
        }
        if (data.text) {
          setContent(data.text);
          finalContent = data.text;
        }

        if (!finalContent.trim()) {
          throw new Error("Could not extract any meaningful text from the provided URL. Please paste content manually.");
        }

        onSubmit({
          content: finalContent.trim(),
          title: finalTitle.trim() || `Untapped Page Audit (${new Date().toLocaleDateString()})`,
          sourceType,
          sourceUrl: sourceUrl.trim()
        });
      } catch (err: any) {
        setFetchError(err.message || "Failed to automatically fetch URL content.");
      } finally {
        setIsFetchingUrl(false);
      }
      return;
    }

    if (!content.trim()) return;

    onSubmit({
      content: content.trim(),
      title: title.trim() || `Untapped Page Audit (${new Date().toLocaleDateString()})`,
      sourceType,
      sourceUrl: sourceUrl.trim()
    });
  };

  const getSourceIcon = (type: string) => {
    switch (type) {
      case "youtube": return <Youtube className="h-4 w-4 text-red-500" />;
      case "social_media": return <Share2 className="h-4 w-4 text-sky-400" />;
      case "web_article": return <Globe className="h-4 w-4 text-emerald-400" />;
      default: return <FileText className="h-4 w-4 text-slate-400" />;
    }
  };

  return (
    <div className="border-loader-container active shadow-2xl">
      <form onSubmit={handleFormSubmit} className="border-loader-overlay space-y-5 p-6" id="eval-form">
        <div>
          <h3 className="text-base font-bold text-white font-display mb-1 flex items-center gap-2">
            <Typewriter text="Content Assessment Panel" speed={30} />
          </h3>
          <p className="text-xs text-slate-400 leading-normal">
            Load reference URL metadata or paste raw transcripts directly to run checking.
          </p>
        </div>

        {/* Google Drive Integration Dashboard Panel */}
        <div className="p-4 bg-[#0D0D11]/90 border border-slate-850 rounded-xl relative overflow-hidden flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-md">
          <div className="flex items-center gap-3">
            <div className={`p-2.5 rounded shrink-0 ${
              driveToken 
                ? "bg-blue-950/40 text-blue-400 border border-blue-900/40" 
                : "bg-slate-900 text-slate-500 border border-slate-800"
            }`}>
              <HardDrive className="h-5 w-5" />
            </div>
            <div>
              <span className="text-[10px] font-bold font-mono text-slate-500 uppercase tracking-widest block">
                Google Drive Vault
              </span>
              {driveUser ? (
                <p className="text-xs text-slate-200 mt-0.5">
                  Connected: <strong className="text-blue-400 font-mono text-[11.5px]">{driveUser.email}</strong>
                </p>
              ) : (
                <p className="text-xs text-slate-400 mt-0.5">
                  Link with Google Drive securely to audit native documents.
                </p>
              )}
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            {driveUser ? (
              <>
                <button
                  type="button"
                  onClick={() => setIsDriveModalOpen(true)}
                  className="px-3.5 py-1.5 bg-blue-900/30 hover:bg-blue-900/50 border border-blue-750 text-blue-200 rounded text-xs font-semibold uppercase tracking-wider font-mono transition-all cursor-pointer flex items-center gap-1.5"
                >
                  <FolderOpen className="h-3.5 w-3.5" />
                  <span>Import File</span>
                </button>
                <button
                  type="button"
                  onClick={onDisconnectDrive}
                  className="p-1.5 bg-slate-850 hover:bg-slate-800 text-slate-450 hover:text-red-400 rounded transition-colors cursor-pointer border border-slate-800"
                  title="Disconnect Google Drive"
                >
                  <LogOut className="h-3.5 w-3.5" />
                </button>
              </>
            ) : (
              <button
                type="button"
                onClick={onConnectDrive}
                className="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-705 border border-slate-700 text-slate-200 rounded text-xs font-semibold uppercase tracking-wider font-mono transition-all cursor-pointer flex items-center gap-1.5"
              >
                <HardDrive className="h-3.5 w-3.5 text-slate-400" />
                <span>Connect Drive</span>
              </button>
            )}
          </div>
        </div>

        {driveImportSuccess && (
          <div className="p-3 bg-emerald-950/20 border border-emerald-900/30 rounded-lg flex items-center gap-2 text-emerald-400 text-xs animate-slide-in">
            <CheckCircle className="h-4 w-4 shrink-0" />
            <span className="flex-1">
              Google Drive asset loaded successfully: <strong className="text-white font-mono">{driveImportSuccess}</strong>
            </span>
            <button
              type="button"
              onClick={() => setDriveImportSuccess("")}
              className="p-1 hover:bg-slate-800 rounded text-slate-400 hover:text-white"
            >
              <X className="h-3 w-3" />
            </button>
          </div>
        )}

      <div className="space-y-4 pt-1">
        {/* Source URL URL link inputs */}
        <div className="space-y-1.5">
          <label htmlFor="source-url" className="text-xs font-semibold uppercase tracking-widest font-mono flex items-center justify-between">
            <span className="text-yellow-400 font-extrabold flex items-center gap-1.5 drop-shadow-[0_0_10px_rgba(234,179,8,0.7)]">
              <span className="inline-block w-1.5 h-1.5 rounded-full bg-yellow-400 animate-pulse shrink-0"></span>
              Content Source URL
            </span>
            <span className="text-[10px] text-slate-500 font-normal normal-case">Optional</span>
          </label>
          <div className="flex gap-2">
            <input
              id="source-url"
              type="url"
              placeholder="Paste URL (YouTube, Twitter, URL)..."
              value={sourceUrl}
              onChange={(e) => setSourceUrl(e.target.value)}
              disabled={isLoading || isFetchingUrl}
              className="flex-1 px-4 py-3 text-sm bg-[#16161A] border border-slate-800 rounded text-slate-200 placeholder-slate-600 focus:outline-none focus:border-red-550 focus:bg-[#16161A] transition-all"
            />
            {sourceUrl && (
              <button
                type="button"
                onClick={handleUrlFetch}
                disabled={isFetchingUrl || isLoading}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 disabled:bg-slate-900 border border-slate-700 disabled:border-slate-850 text-slate-200 disabled:text-slate-600 font-semibold rounded text-xs uppercase tracking-wider font-mono flex items-center gap-2 transition-all shrink-0 cursor-pointer"
                id="btn-fetch-url"
              >
                {isFetchingUrl ? (
                  <>
                    <Loader2 className="h-3.5 w-3.5 animate-spin" />
                    <span>Extracting...</span>
                  </>
                ) : (
                  <span>{sourceType === "youtube" ? "Fetch Video" : "Fetch Text"}</span>
                )}
              </button>
            )}
          </div>
          {fetchWarning && (
            <p className="text-[11px] text-amber-400 bg-amber-950/20 border border-amber-900/30 rounded p-2.5 leading-relaxed font-sans">
              {fetchWarning}
            </p>
          )}
          {fetchError && (
            <p className="text-[11px] text-red-400 bg-red-950/20 border border-red-900/30 rounded p-2.5 leading-relaxed font-sans">
              {fetchError}
            </p>
          )}
        </div>

        {/* Source Type Metadata Pickers */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 py-3">
          {(['youtube', 'social_media', 'web_article', 'other'] as const).map((type) => (
            <button
              key={type}
              type="button"
              onClick={() => setSourceType(type)}
              disabled={isLoading || isFetchingUrl}
              className={`glowing-source-btn ${type} ${sourceType === type ? "active" : ""}`}
            >
              <div className="layer">
                <span></span>
                <span></span>
                <span></span>
                <span></span>
                <span>
                  {getSourceIcon(type)}
                </span>
              </div>
              <div className="text">
                {type === "social_media" ? "Social" : type === "web_article" ? "Web URL" : type === "youtube" ? "Youtube" : "Other"}
              </div>
            </button>
          ))}
        </div>

        {/* Title metadata fields */}
        <div className="space-y-1.5">
          <label htmlFor="content-title" className="text-xs font-semibold text-slate-500 uppercase tracking-widest font-mono flex items-center justify-between">
            <span className="bright-yellow-title font-bold text-sm">Asset Title / Reference</span>
            <span className="text-[10px] text-slate-600 font-normal normal-case">Optional</span>
          </label>
          <input
            id="content-title"
            type="text"
            placeholder="e.g., Slot machine beat hacks review, medical video critique title"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            disabled={isLoading || isFetchingUrl}
            className="w-full px-4 py-3 text-sm bg-[#16161A] border border-slate-800 rounded text-slate-200 placeholder-slate-600 focus:outline-none focus:border-red-550 focus:bg-[#16161A] transition-all"
          />
        </div>

        {/* Paste Transcript Text Box */}
        <div className="space-y-1.5">
          <label htmlFor="raw-content" className="text-xs font-semibold text-slate-500 uppercase tracking-widest font-mono flex items-center justify-between">
            <span className="bright-yellow-title font-bold text-sm">Raw Transcription / Content Text</span>
            <span className="text-[10px] text-red-500 font-bold uppercase tracking-wider">Required</span>
          </label>
          <textarea
            id="raw-content"
            required={!sourceUrl.trim()}
            placeholder="Paste raw transcript, comments, blog paragraphs, or post caption text here for deep analysis..."
            value={content}
            onChange={(e) => setContent(e.target.value)}
            disabled={isLoading || isFetchingUrl}
            rows={10}
            className="w-full px-4 py-3 text-sm bg-[#16161A] border border-slate-800 rounded text-slate-200 placeholder-slate-600 focus:outline-none focus:border-red-550 focus:bg-[#16161A] transition-all font-sans leading-relaxed resize-none"
          ></textarea>
          <div className="flex items-center justify-between text-[10px] text-slate-500 font-mono">
            <span>Length: {content.length} chars</span>
            <span>Approx: {content.split(/\s+/).filter(Boolean).length} words</span>
          </div>
        </div>
      </div>

      <button
        type="submit"
        disabled={isLoading || isFetchingUrl || (!content.trim() && !sourceUrl.trim())}
        className="w-full py-4 bg-red-650 hover:bg-red-550 disabled:bg-slate-900 border border-red-700 disabled:border-slate-850 text-white disabled:text-slate-605 font-bold rounded text-xs uppercase tracking-widest font-mono flex items-center justify-center gap-2 transition-all active:scale-[0.98] shadow-lg cursor-pointer"
        id="btn-evaluate-submit"
      >
        {isLoading ? (
          <>
            <Loader2 className="h-4 w-4 animate-spin text-white" />
            <span>RUNNING RISK ANALYSIS...</span>
          </>
        ) : (
          <>
            <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4" />
            </svg>
            <span>RUN EVALUATION</span>
          </>
        )}
      </button>
    </form>

    {driveToken && (
      <DriveFileSelector
        isOpen={isDriveModalOpen}
        onClose={() => setIsDriveModalOpen(false)}
        token={driveToken}
        onFileSelected={(fileName, fileContent) => {
          setTitle(fileName || "");
          setContent(fileContent || "");
          setSourceUrl("");
          setSourceType("other");
          setDriveImportSuccess(fileName || "Untitled document");
        }}
      />
    )}
    </div>
  );
}
