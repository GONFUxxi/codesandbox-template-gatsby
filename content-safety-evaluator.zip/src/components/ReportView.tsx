import React, { useState, useMemo, Component } from "react";
import { EvaluationResult } from "../types";
import {
  ShieldAlert, ShieldCheck, Calendar, ExternalLink, Globe, Youtube,
  Share2, FileText, CheckCircle2, AlertTriangle, Copy, Check, Download, ArrowLeft, AlertCircle, Columns, HardDrive, Loader2,
  ChevronDown, ChevronUp, TrendingUp, BarChart3, PieChart as LucidePieChart, Trash2
} from "lucide-react";
import { uploadReportToDrive } from "../lib/googleDrive";
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Cell,
  PieChart,
  Pie
} from "recharts";

// 1. Safe ErrorBoundary to prevent any Recharts or visual canvas crashes in production
interface ErrorBoundaryProps {
  children: React.ReactNode;
  fallback: React.ReactNode;
}

interface ErrorBoundaryState {
  hasError: boolean;
}

class ErrorBoundary extends Component<ErrorBoundaryProps, ErrorBoundaryState> {
  readonly props!: ErrorBoundaryProps;
  state: ErrorBoundaryState = {
    hasError: false
  };

  static getDerivedStateFromError(): ErrorBoundaryState {
    return { hasError: true };
  }

  componentDidCatch(error: any, errorInfo: any) {
    console.error("ErrorBoundary caught chart or rendering error:", error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return this.props.fallback;
    }
    return this.props.children;
  }
}

// 2. High-fidelity Pure CSS/Tailwind Bar Chart fallback
function BarChartFallback({ data }: { data: { name: string; count: number; color: string }[] }) {
  const maxCount = Math.max(...data.map(d => d.count), 1);
  return (
    <div className="flex items-end justify-around h-full w-full pt-6 pb-2 px-6 bg-[#0B0B0C] border border-slate-900 rounded-lg">
      {data.map((item, idx) => {
        const pct = (item.count / maxCount) * 100;
        return (
          <div key={idx} className="flex flex-col items-center gap-2 w-12 group">
            <div className="text-[11px] font-mono text-slate-300 font-bold">
              {item.count}
            </div>
            <div 
              className="w-7 rounded-t transition-all duration-700 shadow-md" 
              style={{ 
                height: `${Math.max(pct * 0.9, 8)}px`, 
                backgroundColor: item.color,
                opacity: 0.9
              }}
            />
            <span className="text-[9px] font-mono text-slate-500 uppercase tracking-wider font-semibold">
              {item.name}
            </span>
          </div>
        );
      })}
    </div>
  );
}

// 3. High-fidelity Pure CSS/Tailwind Pie Chart fallback
function PieChartFallback({ data }: { data: { name: string; value: number; color: string }[] }) {
  const total = data.reduce((sum, d) => sum + d.value, 0) || 1;
  return (
    <div className="flex flex-col justify-center h-full gap-3 px-4 bg-[#0B0B0C] border border-slate-900 rounded-lg w-full">
      {data.map((item, idx) => {
        const pct = Math.round((item.value / total) * 100);
        return (
          <div key={idx} className="space-y-1">
            <div className="flex justify-between text-[10px] font-mono">
              <span className="text-slate-400 font-medium">{item.name}</span>
              <span className="font-bold flex items-center gap-1.5" style={{ color: item.color }}>
                {item.value} <span className="text-slate-500 font-normal">({pct}%)</span>
              </span>
            </div>
            <div className="h-2 w-full bg-slate-900/60 rounded-full overflow-hidden border border-slate-850">
              <div 
                className="h-full rounded-full transition-all duration-700" 
                style={{ width: `${pct}%`, backgroundColor: item.color }}
              />
            </div>
          </div>
        );
      })}
    </div>
  );
}

interface ReportViewProps {
  report: EvaluationResult;
  onReset: () => void;
  allReports?: EvaluationResult[];
  driveUser: any | null;
  driveToken: string | null;
  onConnectDrive: () => void;
  onDeleteReport?: (id: string) => void;
}

export default function ReportView({
  report,
  onReset,
  allReports = [],
  driveUser,
  driveToken,
  onConnectDrive,
  onDeleteReport
}: ReportViewProps) {
  const [copied, setCopied] = useState(false);
  const [isSplitMode, setIsSplitMode] = useState(false);
  const [comparisonReportId, setComparisonReportId] = useState<string>("");
  const [isSavingToDrive, setIsSavingToDrive] = useState(false);
  const [driveSaveResult, setDriveSaveResult] = useState<{ success: boolean; filename?: string; error?: string } | null>(null);
  const [showConfirmDelete, setShowConfirmDelete] = useState(false);

  // Analytics pane states & calculations
  const [showAnalytics, setShowAnalytics] = useState(true);

  const distributionData = useMemo(() => {
    const list = allReports && allReports.length > 0 ? allReports : [report];
    const counts = { Safe: 0, Low: 0, Medium: 0, High: 0 };
    list.forEach((item) => {
      const lvl = item.riskLevel || "Safe";
      if (counts.hasOwnProperty(lvl)) {
        counts[lvl as keyof typeof counts]++;
      }
    });

    return [
      { name: "Safe", count: counts.Safe, color: "#10b981" },
      { name: "Low", count: counts.Low, color: "#3b82f6" },
      { name: "Medium", count: counts.Medium, color: "#f59e0b" },
      { name: "High", count: counts.High, color: "#ef4444" }
    ];
  }, [allReports, report]);

  const sourceData = useMemo(() => {
    const list = allReports && allReports.length > 0 ? allReports : [report];
    const counts = { youtube: 0, social_media: 0, web_article: 0, other: 0 };
    list.forEach((item) => {
      const src = item.sourceType || "other";
      if (counts.hasOwnProperty(src)) {
        counts[src as keyof typeof counts]++;
      }
    });

    return [
      { name: "YouTube", value: counts.youtube, color: "#ef4444" },
      { name: "Social Media", value: counts.social_media, color: "#38bdf8" },
      { name: "Web Article", value: counts.web_article, color: "#34d399" },
      { name: "Other Text", value: counts.other, color: "#94a3b8" }
    ].filter(item => item.value > 0);
  }, [allReports, report]);

  const auditStats = useMemo(() => {
    const list = allReports && allReports.length > 0 ? allReports : [report];
    const total = list.length;
    const totalScore = list.reduce((sum, r) => sum + (r.riskScore || 0), 0);
    const avgScore = Math.round(totalScore / total);
    
    const statusCounts = list.reduce((acc, r) => {
      acc[r.status] = (acc[r.status] || 0) + 1;
      return acc;
    }, { safe: 0, flagged: 0 });

    return {
      total,
      avgScore,
      safeCount: statusCounts.safe,
      flaggedCount: statusCounts.flagged
    };
  }, [allReports, report]);

  const getSourceIcon = (type: string) => {
    switch (type) {
      case "youtube": return <Youtube className="h-4 w-4 text-red-500" />;
      case "social_media": return <Share2 className="h-4 w-4 text-sky-400" />;
      case "web_article": return <Globe className="h-4 w-4 text-emerald-400" />;
      default: return <FileText className="h-4 w-4 text-slate-400" />;
    }
  };

  const getRiskColor = (level: string) => {
    switch (level.toLowerCase()) {
      case "safe": return "bg-emerald-950/30 text-emerald-400 border-emerald-900/40";
      case "low": return "bg-blue-950/30 text-blue-400 border-blue-900/40";
      case "medium": return "bg-amber-950/30 text-amber-400 border-amber-900/40";
      case "high": return "bg-red-950/30 text-red-400 border-red-900/40";
      default: return "bg-slate-900 text-slate-300 border-slate-800";
    }
  };

  const getRiskProgressColor = (level: string) => {
    switch (level.toLowerCase()) {
      case "safe": return "bg-emerald-500";
      case "low": return "bg-blue-500";
      case "medium": return "bg-amber-500";
      case "high": return "bg-red-500";
      default: return "bg-slate-500";
    }
  };

  // Convert report findings to copyable Markdown report
  const generateMarkdownReport = () => {
    let md = `# CONTENT AUDIT REPORT: ${report.title.toUpperCase()}\n`;
    md += `**Date:** ${new Date(report.timestamp).toLocaleString()}\n`;
    md += `**Source URL:** ${report.sourceUrl || "N/A"}\n`;
    md += `**Status:** ${report.status.toUpperCase()} (${report.riskLevel} Risk - Score: ${report.riskScore}/100)\n\n`;
    md += `## EXECUTIVE SUMMARY\n${report.summary}\n\n`;
    md += `## GUIDELINE TRIGGER CHECKLIST\n\n`;

    report.triggers.forEach((t, i) => {
      md += `### ${i + 1}. ${t.trigger}\n`;
      md += `* **Status:** ${t.detected ? "❌ TRIGGERED" : "✅ Pass (Clean)"}\n`;
      md += `* **Explanation:** ${t.explanation}\n`;
      if (t.detected && t.evidence) {
        md += `* **Extracted Evidence:** \`${t.evidence}\`\n`;
      }
      md += `\n`;
    });

    if (report.tags && report.tags.length > 0) {
      md += `**Tags:** ${report.tags.join(", ")}\n`;
    }

    return md;
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(generateMarkdownReport());
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const downloadJson = () => {
    const blob = new Blob([JSON.stringify(report, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `safety-audit-${report.id}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleSaveToDrive = async () => {
    if (!driveToken) {
      onConnectDrive();
      return;
    }
    setIsSavingToDrive(true);
    setDriveSaveResult(null);
    try {
      const markdown = generateMarkdownReport();
      const sanitizedTitle = report.title.replace(/[^a-z0-9]/gi, '_').toLowerCase();
      const filename = `safeguard_report_${sanitizedTitle}_${report.id}.md`;
      await uploadReportToDrive(filename, markdown, driveToken);
      setDriveSaveResult({ success: true, filename });
      // Keep it up to let them enjoy the success
      setTimeout(() => setDriveSaveResult(null), 8000);
    } catch (err: any) {
      console.error(err);
      setDriveSaveResult({ success: false, error: err?.message || "Failed to save the report to Google Drive." });
    } finally {
      setIsSavingToDrive(false);
    }
  };

  const renderReportColumn = (data: EvaluationResult, isSecondary: boolean = false) => {
    return (
      <div className="border-loader-container active shadow-xl">
        <div className="border-loader-overlay p-5 space-y-5 animate-fade-in text-slate-200">
        {/* Header summary of column */}
        <div className="border-b border-slate-850 pb-4">
          <div className="flex items-center justify-between gap-2.5 mb-2">
            <span className="text-[10px] font-semibold tracking-widest font-mono text-slate-500 uppercase">
              {isSecondary ? "Comparison Target" : "Primary Audit"}
            </span>
            <span className={`px-2 py-0.5 text-[9px] font-extrabold font-mono tracking-wider uppercase border rounded ${getRiskColor(data.riskLevel)}`}>
              {data.riskLevel} Risk
            </span>
          </div>
          <h4 className="text-sm font-bold text-white tracking-tight line-clamp-1" title={data.title}>
            {data.title}
          </h4>
          <div className="flex items-center gap-1.5 mt-1 text-[10px] text-slate-400 font-mono">
            {getSourceIcon(data.sourceType)}
            <span className="uppercase">{data.sourceType === "web_article" ? "Web Article" : data.sourceType === "social_media" ? "Social" : data.sourceType}</span>
            <span>•</span>
            <span>{new Date(data.timestamp).toLocaleDateString()}</span>
          </div>
        </div>

        {/* Status banner and Score badge */}
        <div className="grid grid-cols-2 gap-4">
          <div className={`p-3 border rounded-xl flex flex-col items-center justify-center text-center ${
            data.status === "safe"
              ? "bg-emerald-950/15 border-emerald-900/30 text-emerald-450"
              : "bg-red-950/15 border-red-900/30 text-red-450"
          }`}>
            {data.status === "safe" ? (
              <ShieldCheck className="h-5 w-5 text-emerald-400 mb-1" />
            ) : (
              <ShieldAlert className="h-5 w-5 text-red-400 mb-1" />
            )}
            <span className="text-[10px] font-extrabold font-mono uppercase tracking-wider block">
              {data.status === "safe" ? "Passed" : "Violated"}
            </span>
          </div>

          <div className="bg-[#141417]/80 border border-slate-850 p-3 rounded-xl flex flex-col items-center justify-center text-center">
            <span className="text-xl font-extrabold font-mono text-white leading-none">
              {data.riskScore}
              <span className="text-[10px] text-slate-500 font-normal">/100</span>
            </span>
            <span className="text-[8px] font-bold text-slate-500 mt-1 uppercase tracking-widest font-mono">
              Aggregate Score
            </span>
          </div>
        </div>

        {/* Executive summary block */}
        <div className="bg-[#141417]/50 border border-slate-850 rounded-lg p-3.5 space-y-1">
          <span className="text-[8px] font-bold tracking-widest text-slate-500 uppercase font-mono block">
            Executive Determination Summary
          </span>
          <p className="text-slate-305 text-xs leading-relaxed max-h-24 overflow-y-auto pr-1 whitespace-pre-line font-medium text-slate-205">
            {data.summary}
          </p>
        </div>

        {/* Trigger check metrics side by side */}
        <div className="space-y-2.5">
          <span className="text-[8px] font-bold tracking-widest text-slate-505 uppercase font-mono block pl-1">
            Verification Checklist
          </span>
          <div className="space-y-2 max-h-[380px] overflow-y-auto pr-1">
            {data.triggers.map((t, index) => (
              <div
                key={index}
                className={`p-2.5 rounded-lg border text-xs flex flex-col gap-1 transition-all ${
                  t.detected
                    ? "bg-red-950/10 border-red-900 text-red-300"
                    : "bg-[#0A0A0C] border-slate-850 text-slate-300"
                }`}
              >
                <div className="flex items-center justify-between gap-1.5">
                  <span className="font-bold line-clamp-1 text-slate-200">
                    {index + 1}. {t.trigger}
                  </span>
                  <span className={`text-[8px] font-extrabold px-1.5 py-0.5 rounded uppercase shrink-0 ${
                    t.detected
                      ? "bg-red-950/40 text-red-400 border border-red-900/30"
                      : "bg-emerald-950/40 text-emerald-400 border border-emerald-900/30"
                  }`}>
                    {t.detected ? "Triggered" : "Passed"}
                  </span>
                </div>
                <p className="text-[11px] text-slate-400 leading-relaxed font-normal">
                  {t.explanation}
                </p>
                {t.detected && t.evidence && (
                  <div className="mt-1.5 p-2 bg-red-950/20 border-l-2 border-red-500 rounded font-mono text-[9.5px] text-red-200/90 leading-tight">
                    &ldquo;{t.evidence}&rdquo;
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
    );
  };

  return (
    <div className="space-y-6" id="report-view">
      {/* Visual top bar actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-[#0D0D0F] border border-slate-800 rounded-xl p-4 shadow-xl">
        <button
          onClick={onReset}
          className="flex items-center gap-2 text-xs uppercase tracking-wider font-semibold text-slate-400 hover:text-white transition-colors cursor-pointer font-mono"
          id="btn-back-audit"
        >
          <ArrowLeft className="h-3.5 w-3.5" />
          <span>Audit another content</span>
        </button>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => {
              setIsSplitMode(!isSplitMode);
            }}
            className={`flex items-center gap-2 px-3.5 py-2 border rounded text-xs font-semibold uppercase font-mono transition-all cursor-pointer ${
              isSplitMode
                ? "bg-red-950/40 hover:bg-red-950/60 text-red-400 border-red-900"
                : "bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200"
            }`}
            title="Compare two evaluation reports side-by-side"
            id="btn-toggle-split"
          >
            <Columns className="h-3.5 w-3.5" />
            <span>{isSplitMode ? "Exit Split View" : "Split View"}</span>
          </button>

          <button
            onClick={copyToClipboard}
            className="flex items-center gap-2 px-3.5 py-2 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 rounded text-xs font-semibold uppercase font-mono transition-all cursor-pointer"
            title="Copy Report in clear Markdown format"
            id="btn-copy-report"
          >
            {copied ? (
              <>
                <Check className="h-3.5 w-3.5 text-emerald-400" />
                <span className="text-emerald-400">Copied MD</span>
              </>
            ) : (
              <>
                <Copy className="h-3.5 w-3.5 text-slate-400" />
                <span>Copy Markdown</span>
              </>
            )}
          </button>

          <button
            onClick={downloadJson}
            className="flex items-center gap-2 px-3.5 py-2 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 rounded text-xs font-semibold uppercase font-mono transition-all cursor-pointer"
            title="Download full audit data blocks"
            id="btn-download-json"
          >
            <Download className="h-3.5 w-3.5 text-slate-400" />
            <span>Export JSON</span>
          </button>

          <button
            onClick={handleSaveToDrive}
            disabled={isSavingToDrive}
            className={`flex items-center gap-2 px-3.5 py-2 rounded text-xs font-semibold uppercase font-mono transition-all cursor-pointer ${
              driveToken
                ? "bg-blue-900/40 hover:bg-blue-900/60 border border-blue-700 text-blue-200"
                : "bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-400"
            }`}
            title={driveToken ? "Save Markdown report directly to Google Drive" : "Connect with Google Drive to save report"}
            id="btn-save-drive"
          >
            {isSavingToDrive ? (
              <>
                <Loader2 className="h-3.5 w-3.5 animate-spin text-blue-400" />
                <span>Saving...</span>
              </>
            ) : (
              <>
                <HardDrive className={`h-3.5 w-3.5 ${driveToken ? "text-blue-400" : "text-slate-500"}`} />
                <span>{driveToken ? "Save to Drive" : "Connect Drive"}</span>
              </>
            )}
          </button>

          {onDeleteReport && (
            <div className="relative inline-block">
              {showConfirmDelete ? (
                <div className="flex items-center gap-1.5 bg-red-950/55 border border-red-800/80 rounded-md p-1 animate-fade-in">
                  <span className="text-[10px] font-mono font-bold text-red-300 px-1 uppercase tracking-wider">¿Borrar? / Delete?</span>
                  <button
                    onClick={() => {
                      onDeleteReport(report.id);
                      onReset();
                    }}
                    className="px-2.5 py-1 bg-red-650 hover:bg-red-550 text-white font-extrabold rounded text-[10px] uppercase font-mono cursor-pointer transition-all"
                  >
                    Sí / Yes
                  </button>
                  <button
                    onClick={() => setShowConfirmDelete(false)}
                    className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-305 border border-slate-700 font-extrabold rounded text-[10px] uppercase font-mono cursor-pointer transition-all"
                  >
                    No
                  </button>
                </div>
              ) : (
                <button
                  onClick={() => setShowConfirmDelete(true)}
                  className="flex items-center gap-2 px-3.5 py-2 bg-red-950/20 hover:bg-red-900/30 border border-red-900/30 text-red-400 hover:text-red-350 rounded text-xs font-semibold uppercase font-mono transition-all cursor-pointer"
                  title="Borrar esta evaluación del historial / Delete this safety audit"
                  id="btn-delete-report-view"
                >
                  <Trash2 className="h-3.5 w-3.5 text-red-400" />
                  <span>Borrar / Delete</span>
                </button>
              )}
            </div>
          )}
        </div>
      </div>

      {driveSaveResult && (
        <div className={`p-4 border rounded-xl flex items-start gap-3 shadow-xl animate-slide-in ${
          driveSaveResult.success
            ? "bg-blue-950/20 border-blue-900/35 text-blue-450"
            : "bg-red-950/20 border-red-900/35 text-red-405"
        }`}>
          <HardDrive className={`h-5 w-5 shrink-0 mt-0.5 ${driveSaveResult.success ? "text-blue-400" : "text-red-400"}`} />
          <div className="flex-1 text-sm font-sans">
            {driveSaveResult.success ? (
              <>
                <span className="font-bold block mb-0.5 uppercase tracking-wider font-mono text-xs">Drive Export Completed</span>
                <span>The neutral safety audit report has been exported as a Markdown file: <strong className="font-mono bg-blue-950/40 px-1 py-0.5 rounded text-white">{driveSaveResult.filename}</strong> inside your connected Google Drive context.</span>
              </>
            ) : (
              <>
                <span className="font-bold block mb-0.5 uppercase tracking-wider font-mono text-xs">Drive Export Blocked</span>
                <span>{driveSaveResult.error}</span>
              </>
            )}
          </div>
          <button
            onClick={() => setDriveSaveResult(null)}
            className="p-1 hover:bg-slate-800 rounded text-slate-400 hover:text-white font-semibold text-xs cursor-pointer"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Recharts Analytics Panel */}
      <div className="bg-[#0C0C0E] border border-slate-850 rounded-xl overflow-hidden shadow-2xl transition-all" id="recharts-analytics-panel">
        {/* Toggle header section */}
        <button
          onClick={() => setShowAnalytics(!showAnalytics)}
          className="w-full flex items-center justify-between p-4 bg-[#101013] hover:bg-[#15151A] transition text-left cursor-pointer border-b border-slate-850"
          id="btn-toggle-analytics"
          type="button"
        >
          <div className="flex items-center gap-2.5">
            <div className="p-1.5 bg-emerald-950/40 text-emerald-400 rounded border border-emerald-900/40">
              <BarChart3 className="h-4.5 w-4.5" />
            </div>
            <div>
              <h3 className="text-xs font-bold text-white font-mono uppercase tracking-widest">
                Global Trust &amp; Safety Portfolio Analytics
              </h3>
              <p className="text-[10px] text-slate-400 mt-0.5">
                Overview of risk grading distributions and coverage across your {auditStats.total} total validated audits.
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2 text-slate-400">
            <span className="text-[10px] font-semibold font-mono uppercase">
              {showAnalytics ? "Collapse Dashboard" : "Expand Dashboard"}
            </span>
            {showAnalytics ? (
              <ChevronUp className="h-4 w-4" />
            ) : (
              <ChevronDown className="h-4 w-4" />
            )}
          </div>
        </button>

        {showAnalytics && (
          <div className="p-5 space-y-6 animate-fade-in" id="analytics-panel-content">
            {/* KPI Stat Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
              <div className="bg-[#121215] border border-slate-850 p-4 rounded-xl flex flex-col justify-center">
                <span className="text-[9px] font-bold text-slate-500 uppercase tracking-widest font-mono">
                  Total Validations
                </span>
                <span className="text-2xl font-extrabold font-mono text-white mt-1">
                  {auditStats.total}
                </span>
                <p className="text-[10px] text-slate-400 mt-0.5">
                  Content items evaluated
                </p>
              </div>

              <div className="bg-[#121215] border border-slate-850 p-4 rounded-xl flex flex-col justify-center">
                <span className="text-[9px] font-bold text-slate-500 uppercase tracking-widest font-mono">
                  Average Risk Coefficient
                </span>
                <span className="text-2xl font-extrabold font-mono text-amber-400 mt-1">
                  {auditStats.avgScore}
                  <span className="text-xs text-slate-500 font-normal">/100</span>
                </span>
                <p className="text-[10px] text-slate-400 mt-0.5">
                  General safety level
                </p>
              </div>

              <div className="bg-[#121215] border border-slate-850 p-4 rounded-xl flex flex-col justify-center">
                <span className="text-[9px] font-bold text-slate-500 uppercase tracking-widest font-mono">
                  Clean / Passed Tracks
                </span>
                <span className="text-2xl font-extrabold font-mono text-emerald-400 mt-1">
                  {auditStats.safeCount}
                </span>
                <p className="text-[10px] text-slate-400 mt-0.5">
                  {Math.round((auditStats.safeCount / auditStats.total) * 100 || 0)}% of portfolio
                </p>
              </div>

              <div className="bg-[#121215] border border-slate-850 p-4 rounded-xl flex flex-col justify-center">
                <span className="text-[9px] font-bold text-slate-404 uppercase tracking-widest font-mono text-red-400/80">
                  Prohibited / Flagged
                </span>
                <span className="text-2xl font-extrabold font-mono text-red-400 mt-1">
                  {auditStats.flaggedCount}
                </span>
                <p className="text-[10px] text-slate-400 mt-0.5">
                  {Math.round((auditStats.flaggedCount / auditStats.total) * 100 || 0)}% of portfolio
                </p>
              </div>
            </div>

            {/* Recharts visualizations */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
              {/* Bar Chart representing risk counts */}
              <div className="bg-[#111114] border border-slate-850 p-4.5 rounded-xl">
                <div className="flex items-center gap-2 mb-4">
                  <BarChart3 className="h-4 w-4 text-blue-400" />
                  <span className="text-[10px] font-bold uppercase tracking-wider font-mono text-slate-300">
                    Hazard Severity Density
                  </span>
                </div>
                <div className="h-48 w-full" id="risk-density-bar-container">
                  <ErrorBoundary fallback={<BarChartFallback data={distributionData} />}>
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart
                        data={distributionData}
                        margin={{ top: 10, right: 10, left: -25, bottom: 0 }}
                      >
                        <XAxis
                          dataKey="name"
                          stroke="#64748b"
                          fontSize={10}
                          tickLine={false}
                          axisLine={false}
                          fontFamily="JetBrains Mono, ui-monospace"
                        />
                        <YAxis
                          stroke="#64748b"
                          fontSize={10}
                          tickLine={false}
                          axisLine={false}
                          tickFormatter={(value) => Math.floor(value).toString()}
                          fontFamily="JetBrains Mono, ui-monospace"
                        />
                        <Tooltip
                          cursor={{ fill: "rgba(30, 41, 59, 0.3)" }}
                          content={({ active, payload }) => {
                            if (active && payload && payload.length) {
                              const data = payload[0].payload;
                              return (
                                <div className="bg-[#09090B] border border-slate-800 p-2 rounded shadow-2xl text-[11px] font-mono">
                                  <span className="font-bold uppercase tracking-wider block" style={{ color: data.color }}>
                                    {data.name} Risk
                                  </span>
                                  <span className="text-slate-355 mt-0.5 block">
                                    Audits Count: <strong className="text-white font-sans">{data.count}</strong>
                                  </span>
                                </div>
                              );
                            }
                            return null;
                          }}
                        />
                        <Bar dataKey="count" radius={[4, 4, 0, 0]}>
                          {distributionData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.color} opacity={0.88} />
                          ))}
                        </Bar>
                      </BarChart>
                    </ResponsiveContainer>
                  </ErrorBoundary>
                </div>
              </div>

              {/* Pie Chart representing verified media sources */}
              <div className="bg-[#111114] border border-slate-850 p-4.5 rounded-xl">
                <div className="flex items-center gap-2 mb-4">
                  <LucidePieChart className="h-4 w-4 text-emerald-400" />
                  <span className="text-[10px] font-bold uppercase tracking-wider font-mono text-slate-300">
                    Source Media Proportions
                  </span>
                </div>
                {sourceData.length === 0 ? (
                  <div className="h-48 flex items-center justify-center text-slate-500 font-mono text-[10.5px]">
                    No categorized media logs.
                  </div>
                ) : (
                  <div className="flex flex-col sm:flex-row items-center justify-between gap-4 h-48">
                    <div className="w-1/2 h-full" id="media-pie-container">
                      <ErrorBoundary fallback={<PieChartFallback data={sourceData} />}>
                        <ResponsiveContainer width="100%" height="100%">
                          <PieChart>
                            <Pie
                              data={sourceData}
                              cx="50%"
                              cy="50%"
                              innerRadius={45}
                              outerRadius={65}
                              paddingAngle={4}
                              dataKey="value"
                            >
                              {sourceData.map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={entry.color} />
                              ))}
                            </Pie>
                            <Tooltip
                              content={({ active, payload }) => {
                                if (active && payload && payload.length) {
                                  const data = payload[0].payload;
                                  return (
                                    <div className="bg-[#09090B] border border-slate-800 p-2 rounded shadow-2xl text-[11px] font-mono">
                                      <span className="font-bold block" style={{ color: data.color }}>
                                        {data.name}
                                      </span>
                                      <span className="text-slate-355 mt-0.5 block">
                                        Count: <strong className="text-white font-sans">{data.value}</strong>
                                      </span>
                                    </div>
                                  );
                                }
                                return null;
                              }}
                            />
                          </PieChart>
                        </ResponsiveContainer>
                      </ErrorBoundary>
                    </div>

                    <div className="space-y-1.5 flex-1 w-full max-w-xs font-mono text-[10px]">
                      {sourceData.map((item, idx) => (
                        <div key={idx} className="flex items-center justify-between py-1 border-b border-slate-900/40">
                          <div className="flex items-center gap-1.5 text-slate-400">
                            <span className="h-2 w-2 rounded-full" style={{ backgroundColor: item.color }} />
                            <span>{item.name}</span>
                          </div>
                          <span className="text-slate-200 font-semibold flex items-center gap-1">
                            {item.value} <span className="text-xs text-slate-500 font-normal">({Math.round((item.value / auditStats.total) * 100)}%)</span>
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </div>

      {isSplitMode ? (
        <div className="grid grid-cols-1 xl:grid-cols-2 gap-6" id="split-view-container">
          {/* Left Column: Primary report */}
          <div className="space-y-4">
            <div className="bg-[#0D0D0F] border border-slate-800 rounded-xl px-4 py-3 flex items-center justify-between gap-3 shadow-md">
              <span className="text-[10px] font-mono tracking-wider font-extrabold text-red-400 uppercase">
                Active Audit Report (Primary)
              </span>
              <span className="text-[9.5px] text-slate-500 font-mono">
                Current selection
              </span>
            </div>
            {renderReportColumn(report, false)}
          </div>

          {/* Right Column: Comparison selector + Comparative report */}
          <div className="space-y-4">
            {(() => {
              const availableReports = allReports.filter((r) => r.id !== report.id);
              const comparisonReport = availableReports.find((r) => r.id === comparisonReportId);

              if (availableReports.length === 0) {
                return (
                  <div className="bg-[#0D0D0F] border border-slate-800 rounded-xl p-8 shadow-xl flex flex-col items-center justify-center text-center min-h-[450px]">
                    <FileText className="h-10 w-10 text-slate-600 mb-3" />
                    <h4 className="text-sm font-bold font-mono uppercase tracking-wider text-slate-350 mb-1">
                      No comparative logs
                    </h4>
                    <p className="text-xs text-slate-500 max-w-xs leading-relaxed mb-4">
                      Create another Trust &amp; Safety audit report first to toggle split-view comparison!
                    </p>
                    <button
                      onClick={() => setIsSplitMode(false)}
                      className="px-4 py-2 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 text-xs font-semibold uppercase font-mono rounded cursor-pointer"
                    >
                      Exit Comparison Mode
                    </button>
                  </div>
                );
              }

              if (!comparisonReport) {
                return (
                  <div className="bg-[#0D0D0F] border border-slate-800 rounded-xl p-8 shadow-xl flex flex-col items-center justify-center text-center min-h-[450px] space-y-4">
                    <div className="h-12 w-12 rounded-full bg-slate-900 border border-slate-800 flex items-center justify-center text-slate-400">
                      <Columns className="h-5 w-5" />
                    </div>
                    <div className="space-y-1">
                      <h4 className="text-sm font-bold font-mono uppercase tracking-wider text-slate-300">
                        Choose Comparison Audit
                      </h4>
                      <p className="text-xs text-slate-500 max-w-xs mx-auto leading-relaxed">
                        Select one of your {availableReports.length} past audits from the dropdown below to place side-by-side.
                      </p>
                    </div>
                    <div className="w-full max-w-xs">
                      <select
                        value={comparisonReportId}
                        onChange={(e) => setComparisonReportId(e.target.value)}
                        className="w-full px-3 py-2 bg-slate-900 border border-slate-800 text-slate-300 text-xs rounded select-none cursor-pointer focus:outline-none focus:border-slate-700 font-mono"
                      >
                        <option value="">-- Select past audit log --</option>
                        {availableReports.map((r) => (
                          <option key={r.id} value={r.id}>
                            {new Date(r.timestamp).toLocaleDateString()} - {r.title.substring(0, 30)}{r.title.length > 30 ? "..." : ""} ({r.riskLevel})
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>
                );
              }

              return (
                <div className="space-y-4 animate-fade-in">
                  <div className="bg-[#0D0D0F] border border-slate-800 rounded-xl px-4 py-2.5 flex items-center justify-between gap-3 shadow-md">
                    <div className="flex items-center gap-2 flex-1 min-w-0">
                      <span className="text-[10px] font-mono tracking-wider font-extrabold text-blue-400 uppercase shrink-0">
                        Compare with:
                      </span>
                      <select
                        value={comparisonReportId}
                        onChange={(e) => setComparisonReportId(e.target.value)}
                        className="bg-[#08080A] border border-slate-800 hover:border-slate-705 text-[#fff]/90 text-[11px] rounded px-2.5 py-1 select-none cursor-pointer focus:outline-none focus:border-slate-700 font-mono truncate max-w-[240px]"
                      >
                        {availableReports.map((r) => (
                          <option key={r.id} value={r.id}>
                            {new Date(r.timestamp).toLocaleDateString()} - {r.title}
                          </option>
                        ))}
                      </select>
                    </div>
                    <button
                      onClick={() => setComparisonReportId("")}
                      className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 hover:text-[#fff] border border-slate-750 rounded text-[10px] font-mono uppercase transition cursor-pointer"
                      title="Clear selection"
                    >
                      Clear
                    </button>
                  </div>
                  {renderReportColumn(comparisonReport, true)}
                </div>
              );
            })()}
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Side: Summary, Risk scorecard */}
        <div className="lg:col-span-1 space-y-6">
          {/* Status banner */}
          <div className={`p-6 border rounded-xl shadow-xl text-center ${
            report.status === "safe"
              ? "bg-emerald-950/20 border-emerald-900/35 text-emerald-300"
              : "bg-red-950/20 border-red-900/35 text-red-300"
          }`}>
            <div className="mx-auto h-12 w-12 rounded-full flex items-center justify-center mb-3">
              {report.status === "safe" ? (
                <ShieldCheck className="h-10 w-10 text-emerald-400" />
              ) : (
                <ShieldAlert className="h-10 w-10 text-red-400" />
              )}
            </div>
            <h4 className="text-lg font-bold font-display">
              {report.status === "safe" ? "Guidelines Passed" : "Guidelines Triggered"}
            </h4>
            <p className="text-[10px] font-bold text-slate-500 mt-1 uppercase font-mono tracking-widest">
              {report.status === "safe" ? "No prohibited promotions found" : "Severe hazard references detected"}
            </p>
          </div>

          {/* Risk Level gauge */}
          <div className="bg-[#0D0D0F] border border-slate-800 rounded-xl p-6 shadow-xl space-y-4">
            <div>
              <span className="text-[10px] font-semibold tracking-widest font-mono text-slate-500 uppercase">
                Aggregated Risk Score
              </span>
              <div className="flex items-baseline justify-between mt-1">
                <span className="text-4xl font-extrabold font-mono text-white tracking-tight">
                  {report.riskScore}
                  <span className="text-lg text-slate-600 font-normal">/100</span>
                </span>
                <span className={`px-2.5 py-1 text-[10px] font-bold font-mono tracking-wider uppercase border rounded ${getRiskColor(report.riskLevel)}`}>
                  {report.riskLevel} Risk
                </span>
              </div>
            </div>

            {/* Risk range gradient track */}
            <div className="space-y-1.5">
              <div className="h-2.5 w-full bg-[#16161A] rounded overflow-hidden relative border border-slate-800">
                <div
                  className={`h-full rounded transition-all duration-1000 ${getRiskProgressColor(report.riskLevel)}`}
                  style={{ width: `${report.riskScore}%` }}
                ></div>
              </div>
              <div className="flex justify-between text-[9px] font-bold font-mono text-slate-550">
                <span>SAFE</span>
                <span>LOW</span>
                <span>MEDIUM</span>
                <span>HIGH</span>
              </div>
            </div>
          </div>

          {/* Metadata properties */}
          <div className="bg-[#0D0D0F] border border-slate-800 rounded-xl p-6 shadow-xl space-y-3.5 text-xs text-slate-300">
            <span className="text-[10px] font-semibold tracking-widest font-mono text-slate-500 uppercase block">
              Asset Properties
            </span>
            <div className="space-y-2.5">
              <div className="flex items-center justify-between py-1.5 border-b border-slate-850">
                <span className="text-slate-500 font-mono">Platform</span>
                <span className="flex items-center gap-1.5 font-semibold text-slate-350 uppercase font-mono">
                  {getSourceIcon(report.sourceType)}
                  {report.sourceType === "web_article" ? "Website" : report.sourceType === "social_media" ? "Social" : report.sourceType}
                </span>
              </div>
              <div className="flex items-center justify-between py-1.5 border-b border-slate-850">
                <span className="text-slate-500 font-mono">Audited Date</span>
                <span className="flex items-center gap-1.5 font-semibold text-slate-350">
                  <Calendar className="h-3.5 w-3.5 text-slate-500" />
                  {new Date(report.timestamp).toLocaleDateString()}
                </span>
              </div>
              {report.sourceUrl && (
                <div className="flex items-center justify-between py-1.5">
                  <span className="text-slate-500 font-mono">Reference URL</span>
                  <a
                    href={report.sourceUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-1 text-blue-400 hover:text-blue-300 font-semibold truncate max-w-[150px]"
                  >
                    <span className="truncate">{report.sourceUrl}</span>
                    <ExternalLink className="h-3 w-3 shrink-0" />
                  </a>
                </div>
              )}
            </div>

            {report.tags && report.tags.length > 0 && (
              <div className="pt-2">
                <span className="text-slate-500 font-mono block mb-1.5 text-[9px] uppercase tracking-wide">Classifications</span>
                <div className="flex flex-wrap gap-1">
                  {report.tags.map((tag) => (
                    <span
                      key={tag}
                      className="px-2 py-0.5 bg-slate-800 hover:bg-slate-705 text-slate-300 rounded font-mono text-[9px] font-semibold border border-slate-700"
                    >
                      #{tag}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Right Side: Detailed auditor report findings */}
        <div className="lg:col-span-2 space-y-6">
          {/* Executive Overview card */}
          <div className="bg-[#0D0D0F] border border-slate-800 rounded-xl p-6 shadow-xl space-y-2.5">
            <h4 className="text-[10px] font-bold tracking-widest text-slate-500 uppercase font-mono">
              Executive Determination Summary
            </h4>
            <p className="text-slate-205 text-sm leading-relaxed whitespace-pre-line font-medium text-slate-200">
              {report.summary}
            </p>
          </div>

          {/* Trigger list checklist */}
          <div className="space-y-4">
            <h4 className="text-[10px] font-bold tracking-widest text-slate-505 uppercase font-mono px-1">
              Trigger-by-Trigger Verification
            </h4>

            <div className="space-y-3">
              {report.triggers.map((t, idx) => (
                <div
                  key={idx}
                  className={`border rounded-xl p-5 shadow-2xl transition-all ${
                    t.detected
                      ? "border-red-900 bg-red-950/10"
                      : "border-slate-850 bg-[#0D0D0F] hover:border-slate-800"
                  }`}
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 mb-3.5">
                    <div className="flex items-start gap-2.5">
                      <span className="h-5.5 w-5.5 bg-slate-850 text-slate-350 rounded flex items-center justify-center font-mono text-xs font-bold shrink-0 mt-0.5">
                        {idx + 1}
                      </span>
                      <p className="font-bold text-white text-sm leading-tight">
                        {t.trigger}
                      </p>
                    </div>

                    <div className="shrink-0 flex">
                      {t.detected ? (
                        <span className="inline-flex items-center gap-1px px-2.5 py-1 bg-red-950/30 text-red-400 border border-red-905 rounded text-[9px] font-extrabold font-mono tracking-wider uppercase">
                          <AlertTriangle className="h-3 w-3 shrink-0 mr-1 text-red-500" />
                          <span>Violated</span>
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1px px-2.5 py-1 bg-emerald-950/30 text-emerald-400 border border-emerald-905 rounded text-[9px] font-extrabold font-mono tracking-wider uppercase">
                          <CheckCircle2 className="h-3 w-3 shrink-0 mr-1 text-emerald-500" />
                          <span>Clear</span>
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="space-y-3 pl-0 sm:pl-8">
                    {/* Factual explanation */}
                    <div className="text-xs text-slate-300 leading-relaxed">
                      <span className="font-semibold text-slate-500 font-mono text-[9px] tracking-wider block mb-0.5 uppercase">
                        Objective Assessment
                      </span>
                      {t.explanation}
                    </div>

                    {/* Extracted block evidence */}
                    {t.detected && t.evidence && (
                      <div className="p-3.5 bg-red-950/20 border-l-[3px] border-red-500 rounded font-mono text-[11px] text-slate-250 leading-relaxed text-red-200">
                        <span className="font-bold text-red-450 block text-[9px] mb-1 font-sans uppercase tracking-wider">
                          Flagged Transcript Evidence:
                        </span>
                        &ldquo;{t.evidence}&rdquo;
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    )}
    </div>
  );
}
