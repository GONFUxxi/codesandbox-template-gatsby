import React, { useState, useEffect } from "react";

interface TypewriterProps {
  text: string;
  speed?: number;
  delay?: number;
  className?: string;
  as?: "h1" | "h2" | "h3" | "span" | "div";
}

export default function Typewriter({
  text,
  speed = 30, // typing speed in ms per character
  delay = 0,  // initial start delay in ms
  className = "",
  as: Component = "span",
}: TypewriterProps) {
  const [displayedText, setDisplayedText] = useState("");

  useEffect(() => {
    let isMounted = true;
    setDisplayedText(""); // Reset text on text change

    const startTimeout = setTimeout(() => {
      let currentString = "";
      let index = 0;

      const typingInterval = setInterval(() => {
        if (!isMounted) return;

        if (index < text.length) {
          currentString += text[index];
          setDisplayedText(currentString);
          index++;
        } else {
          clearInterval(typingInterval);
        }
      }, speed);

      // Clean up typing interval
      return () => {
        clearInterval(typingInterval);
      };
    }, delay);

    // Clean up start timeout
    return () => {
      isMounted = false;
      clearTimeout(startTimeout);
    };
  }, [text, speed, delay]);

  return <Component className={className}>{displayedText}</Component>;
}
