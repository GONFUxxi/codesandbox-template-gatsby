export interface TriggerResult {
  trigger: string;
  detected: boolean;
  evidence: string;
  explanation: string;
}

export interface EvaluationResult {
  id: string;
  timestamp: string;
  title: string;
  sourceType: 'youtube' | 'social_media' | 'web_article' | 'other';
  sourceUrl?: string;
  rawContent: string;
  status: 'safe' | 'flagged';
  riskScore: number; // 0-100
  riskLevel: 'Safe' | 'Low' | 'Medium' | 'High';
  triggers: TriggerResult[];
  summary: string;
  tags: string[];
}

export const OBJECTIVE_GUIDELINES = {
  skill: "Evaluation of Harmful, Hateful, and Deceptive Content",
  purpose: "Identify and categorize content that causes damage to individuals, groups, or society based strictly on provided objective guidelines, avoiding personal, religious, or political bias.",
  classification_framework: {
    category: "Harmful Content",
    definition: "Directly causes or encourages physical, mental, emotional, or financial harm.",
    critical_triggers: [
      "Serious death threats or doxxing.",
      "Easy-to-replicate violent instructions.",
      "Glorification of atrocities or abuse.",
      "Promotion of self-harm, suicide, or severe eating disorders.",
      "Dangerous non-food consumption (e.g., household chemicals).",
      "High-risk unbacked medical claims contradicting expert consensus.",
      "Financial scams, phishing, or fake high-yield investment guarantees.",
      "Claims of guaranteed patterns or \"hacks\" for random games of chance."
    ]
  }
};
