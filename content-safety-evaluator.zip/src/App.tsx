import React, { useState, useEffect } from "react";
import Header from "./components/Header";
import GuidelinesPanel from "./components/GuidelinesPanel";
import InputForm from "./components/InputForm";
import AuditLoader from "./components/AuditLoader";
import ReportView from "./components/ReportView";
import HistorySidebar from "./components/HistorySidebar";
import MatrixBackground from "./components/MatrixBackground";
import TaskClock from "./components/TaskClock";
import Typewriter from "./components/Typewriter";
import { EvaluationResult } from "./types";
import { ShieldCheck, Calendar, BookOpen, AlertCircle, FileText, Globe, Star, Plus } from "lucide-react";
import { initAuthListener, signInWithGoogle, logOutGoogle, getCachedToken, setCachedToken } from "./lib/googleDrive";
import { User } from "firebase/auth";

export default function App() {
  const [history, setHistory] = useState<EvaluationResult[]>([]);
  const [currentReport, setCurrentReport] = useState<EvaluationResult | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [showGuidelines, setShowGuidelines] = useState(false);
  const [showHistory, setShowHistory] = useState(true);
  const [errorMessage, setErrorMessage] = useState("");

  // Google Drive state
  const [driveUser, setDriveUser] = useState<User | null>(null);
  const [driveToken, setDriveToken] = useState<string | null>(null);

  // Load history from localStorage on mount and init Drive auth
  useEffect(() => {
    try {
      const stored = localStorage.getItem("safety_audit_logs");
      if (stored) {
        setHistory(JSON.parse(stored));
      }
    } catch (e) {
      console.error("Error reading safety_audit_logs from localStorage:", e);
    }

    // Connect auth listener for Google Drive / Firebase Auth
    const unsubscribe = initAuthListener(
      (user, token) => {
        setDriveUser(user);
        setDriveToken(token);
      },
      () => {
        setDriveUser(null);
        setDriveToken(null);
      }
    );

    return () => {
      unsubscribe();
    };
  }, []);

  const handleConnectDrive = async () => {
    try {
      setErrorMessage("");
      const res = await signInWithGoogle();
      if (res) {
        setDriveUser(res.user);
        setDriveToken(res.token);
      }
    } catch (error: any) {
      console.error("Failed to connect drive:", error);
      setErrorMessage("Failed to authorize/connect Google Drive: " + (error?.message || error));
    }
  };

  const handleDisconnectDrive = async () => {
    try {
      await logOutGoogle();
      setDriveUser(null);
      setDriveToken(null);
    } catch (error: any) {
      console.error("Failed to disconnect drive:", error);
    }
  };

  const handlePerformAudit = async (data: {
    content: string;
    title: string;
    sourceType: 'youtube' | 'social_media' | 'web_article' | 'other';
    sourceUrl: string;
  }) => {
    setIsLoading(true);
    setErrorMessage("");
    setCurrentReport(null);

    try {
      const resp = await fetch("/api/evaluate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data)
      });

      let parsed: any;
      const contentType = resp.headers.get("content-type");
      if (contentType && contentType.includes("application/json")) {
        parsed = await resp.json();
      } else {
        const rawText = await resp.text();
        const snippet = rawText.substring(0, 80).trim();
        throw new Error(
          `The server issued a non-JSON response (${resp.status}): "${snippet}...". This usually indicates a server startup delay or unconfigured API key. Please check your GEMINI_API_KEY inside Settings > Secrets.`
        );
      }

      if (!resp.ok) {
        throw new Error(parsed?.error || `Evaluation failed with status code ${resp.status}`);
      }

      const reportId = Math.random().toString(36).substring(2, 11);
      const newReport: EvaluationResult = {
        id: reportId,
        timestamp: new Date().toISOString(),
        title: data.title,
        sourceType: data.sourceType,
        sourceUrl: data.sourceUrl,
        rawContent: data.content,
        status: parsed.status,
        riskScore: parsed.riskScore,
        riskLevel: parsed.riskLevel,
        triggers: parsed.triggers,
        summary: parsed.summary,
        tags: parsed.tags
      };

      setCurrentReport(newReport);
      setHistory((prev) => {
        const updated = [newReport, ...prev];
        localStorage.setItem("safety_audit_logs", JSON.stringify(updated));
        return updated;
      });
    } catch (err: any) {
      setErrorMessage(err.message || "An unexpected error occurred during trust & safety inspection.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleDeleteReport = (id: string) => {
    setHistory((prev) => {
      const updated = prev.filter((item) => item.id !== id);
      localStorage.setItem("safety_audit_logs", JSON.stringify(updated));
      return updated;
    });

    if (currentReport?.id === id) {
      setCurrentReport(null);
    }
  };

  const handleClearHistory = () => {
    setHistory([]);
    localStorage.removeItem("safety_audit_logs");
    setCurrentReport(null);
  };

  const handleImportHistory = (imported: EvaluationResult[]) => {
    setHistory((prev) => {
      // De-duplicate lists by id
      const combined = [...imported, ...prev];
      const unique = combined.filter((v, i, a) => a.findIndex((t) => t.id === v.id) === i);
      localStorage.setItem("safety_audit_logs", JSON.stringify(unique));
      return unique;
    });
  };

  return (
    <div className="flex flex-col min-h-screen bg-transparent text-slate-200 selection:bg-red-500/20 selection:text-red-200" id="app-container">
      <MatrixBackground />
      <Header
        onShowGuidelines={() => setShowGuidelines((prev) => !prev)}
        onShowHistory={() => setShowHistory((prev) => !prev)}
        showHistoryBadge={history.length}
      />

      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6" id="main-content">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          
          {/* Left Column: Historical Logs (Conditional display sidebar toggle) */}
          {showHistory && (
            <div className="lg:col-span-3 h-[calc(100vh-140px)] sticky top-20 z-10 hidden lg:block">
              <HistorySidebar
                history={history}
                onSelectReport={(report) => {
                  setErrorMessage("");
                  setCurrentReport(report);
                }}
                onDeleteReport={handleDeleteReport}
                onClearHistory={handleClearHistory}
                onImportHistory={handleImportHistory}
                onClose={() => setShowHistory(false)}
              />
            </div>
          )}

          {/* Main workspace Column */}
          <div className={`${
            showHistory ? "lg:col-span-9" : "lg:col-span-12"
          } space-y-6`}>
            
            {/* Error alerts banner */}
            {errorMessage && (
              <div className="p-4 bg-red-950/20 border border-red-900/30 rounded-xl flex items-start gap-3 shadow-xl text-red-400 animate-slide-in">
                <AlertCircle className="h-5 w-5 text-red-500 shrink-0 mt-0.5" />
                <div className="flex-1 text-sm">
                  <span className="font-bold block mb-0.5 uppercase tracking-wider font-mono text-xs">Audit Request Interrupted</span>
                  <span>{errorMessage}</span>
                </div>
                <button
                  onClick={() => setErrorMessage("")}
                  className="p-1 hover:bg-slate-800 rounded text-slate-400 font-semibold text-xs cursor-pointer"
                >
                  Dismiss
                </button>
              </div>
            )}

            {/* Expansions: Active guidelines list */}
            {showGuidelines && (
              <div className="animate-fade-in">
                <GuidelinesPanel onClose={() => setShowGuidelines(false)} />
              </div>
            )}

            {/* Task Clock Sprint & Focus Tracker */}
            <TaskClock />

            {/* Mobile History View Button */}
            <div className="lg:hidden flex gap-2">
              <button
                onClick={() => {
                  const mSidebar = document.getElementById("mobile-history");
                  if (mSidebar) mSidebar.classList.toggle("hidden");
                }}
                className="w-full flex items-center justify-center gap-2 py-2.5 px-4 bg-[#0D0D0F] border border-slate-800 text-slate-350 hover:bg-[#16161A] font-semibold rounded text-xs uppercase tracking-widest font-mono cursor-pointer"
              >
                <span>Toggle Historical logs ({history.length})</span>
              </button>
            </div>

            {/* Custom hidden element which functions as mobile popup layout */}
            <div id="mobile-history" className="lg:hidden hidden animate-slide-in bg-[#0D0D0F] border border-slate-800 rounded-xl p-4">
              <HistorySidebar
                history={history}
                onSelectReport={(report) => {
                  setErrorMessage("");
                  setCurrentReport(report);
                  const mSidebar = document.getElementById("mobile-history");
                  if (mSidebar) mSidebar.classList.add("hidden");
                }}
                onDeleteReport={handleDeleteReport}
                onClearHistory={handleClearHistory}
                onImportHistory={handleImportHistory}
                onClose={() => {
                  const mSidebar = document.getElementById("mobile-history");
                  if (mSidebar) mSidebar.classList.add("hidden");
                }}
              />
            </div>

            {/* Core States routing */}
            {isLoading ? (
              <div className="animate-pulse">
                <AuditLoader />
              </div>
            ) : currentReport ? (
              <div className="animate-fade-in">
                <ReportView
                  report={currentReport}
                  allReports={history}
                  onReset={() => setCurrentReport(null)}
                  driveUser={driveUser}
                  driveToken={driveToken}
                  onConnectDrive={handleConnectDrive}
                  onDeleteReport={handleDeleteReport}
                />
              </div>
            ) : (
              <div className="space-y-6">
                <div className="bg-[#0F0F11] border border-slate-850 rounded-xl p-8 text-white relative overflow-hidden shadow-2xl">
                  {/* Visual Background grid overlay pattern and glow */}
                  <div className="absolute inset-0 bg-gradient-to-tr from-red-600/5 via-transparent to-transparent"></div>
                  <div className="absolute -right-20 -top-20 h-50 w-50 bg-red-650/5 rounded-full blur-3xl"></div>
                  
                  <div className="relative max-w-2xl space-y-4">
                    <span className="px-2.5 py-1 bg-red-950/30 border border-red-900/30 rounded text-[9px] font-extrabold font-mono text-red-400 uppercase tracking-widest leading-none inline-block">
                      Objective Policy Evaluator
                    </span>
                    <h2 className="text-xl md:text-2.5xl font-extrabold tracking-tight font-display text-white leading-tight">
                      <Typewriter text="Neutral audits for harmful, hateful & deceptive content." speed={25} />
                    </h2>
                    <p className="text-slate-400 text-xs md:text-sm leading-relaxed max-w-xl font-normal">
                      Examine any URL text, transcript listings, or media paragraph instantly. Checks direct triggers to identify daggers, financial threats, medical disinformation, and random gambling tricks bias-free.
                    </p>
                  </div>
                </div>

                <InputForm
                  onSubmit={handlePerformAudit}
                  isLoading={isLoading}
                  driveUser={driveUser}
                  driveToken={driveToken}
                  onConnectDrive={handleConnectDrive}
                  onDisconnectDrive={handleDisconnectDrive}
                />
              </div>
            )}
          </div>

        </div>
      </main>
    </div>
  );
}
