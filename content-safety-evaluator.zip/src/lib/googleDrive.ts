import { initializeApp } from "firebase/app";
import { getAuth, signInWithPopup, GoogleAuthProvider, onAuthStateChanged, User, signOut } from "firebase/auth";
import firebaseConfig from "../../firebase-applet-config.json";

// Initialize Firebase App
const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);

// Supported scopes for Google Drive
export const DRIVE_SCOPES = [
  "https://www.googleapis.com/auth/drive",
  "https://www.googleapis.com/auth/drive.file",
  "https://www.googleapis.com/auth/drive.readonly",
  "https://www.googleapis.com/auth/drive.metadata",
  "https://www.googleapis.com/auth/drive.metadata.readonly"
];

// Memory cache for active access token
let cachedAccessToken: string | null = null;
let isSigningIn = false;

// Set up the listener for Auth state changes
export const initAuthListener = (
  onSuccess: (user: User, token: string) => void,
  onNeedLogin: () => void
) => {
  return onAuthStateChanged(auth, async (user) => {
    if (user) {
      if (cachedAccessToken) {
        onSuccess(user, cachedAccessToken);
      } else {
        // If we have a user but no cached token (due to refresh/page reload), 
        // we'll ask the user to click Sign In to retrieve a fresh OAuth token safely.
        onNeedLogin();
      }
    } else {
      cachedAccessToken = null;
      onNeedLogin();
    }
  });
};

// Sign in with Google Popup
export const signInWithGoogle = async (): Promise<{ user: User; token: string } | null> => {
  if (isSigningIn) return null;
  isSigningIn = true;
  try {
    const provider = new GoogleAuthProvider();
    DRIVE_SCOPES.forEach(scope => provider.addScope(scope));
    // Hint select_account to make testing multiple users easy
    provider.setCustomParameters({
      prompt: "select_account"
    });

    const result = await signInWithPopup(auth, provider);
    const credential = GoogleAuthProvider.credentialFromResult(result);
    const token = credential?.accessToken;

    if (!token) {
      throw new Error("Could not acquire Google Drive OAuth token from sign-in.");
    }

    cachedAccessToken = token;
    return { user: result.user, token };
  } catch (error) {
    console.error("error during google sign-in:", error);
    throw error;
  } finally {
    isSigningIn = false;
  }
};

// Log out
export const logOutGoogle = async () => {
  await signOut(auth);
  cachedAccessToken = null;
};

// Retrieve currently cached access token
export const getCachedToken = (): string | null => {
  return cachedAccessToken;
};

// Set token directly (e.g. state management fallback)
export const setCachedToken = (token: string | null) => {
  cachedAccessToken = token;
};

// ==========================================
// Google Drive Rest API operations
// ==========================================

export interface DriveFile {
  id: string;
  name: string;
  mimeType: string;
  size?: string;
  modifiedTime?: string;
  iconLink?: string;
}

// List files from Google Drive
export const listDriveFiles = async (token: string): Promise<DriveFile[]> => {
  const qStr = encodeURIComponent("trashed = false");
  const fields = encodeURIComponent("files(id, name, mimeType, size, modifiedTime, iconLink)");
  const url = `https://www.googleapis.com/drive/v3/files?q=${qStr}&fields=${fields}&orderBy=modifiedTime desc&pageSize=40`;

  const response = await fetch(url, {
    method: "GET",
    headers: {
      Authorization: `Bearer ${token}`,
      Accept: "application/json"
    }
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}));
    throw new Error(errorData?.error?.message || `Failed to fetch Google Drive files (HTTP ${response.status})`);
  }

  const data = await response.json();
  return data.files || [];
};

// Read or export text contents of a Google Drive file
export const getDriveFileContent = async (fileId: string, mimeType: string, token: string): Promise<string> => {
  // If it's a Google Doc, we export it as plain text
  if (mimeType === "application/vnd.google-apps.document") {
    const exportUrl = `https://www.googleapis.com/drive/v3/files/${fileId}/export?mimeType=text/plain`;
    const response = await fetch(exportUrl, {
      method: "GET",
      headers: {
        Authorization: `Bearer ${token}`
      }
    });

    if (!response.ok) {
      const err = await response.json().catch(() => ({}));
      throw new Error(err?.error?.message || `Failed to export Google Document (HTTP ${response.status})`);
    }

    return await response.text();
  }

  // Otherwise, we fetch the media content directly
  const downloadUrl = `https://www.googleapis.com/drive/v3/files/${fileId}?alt=media`;
  const response = await fetch(downloadUrl, {
    method: "GET",
    headers: {
      Authorization: `Bearer ${token}`
    }
  });

  if (!response.ok) {
    if (response.status === 403) {
      throw new Error("This file standard binary content cannot be loaded directly. For spreadsheets, presentations or PDFs, please utilize text-based files (.txt, .md, .json) or native Google Documents to run audits.");
    }
    throw new Error(`Failed to download file content (HTTP ${response.status})`);
  }

  return await response.text();
};

// Upload evaluation report as Markdown to Google Drive
export const uploadReportToDrive = async (
  filename: string,
  markdownContent: string,
  token: string
): Promise<DriveFile> => {
  // Step 1: Create metadata to obtain folder placement / document ID
  const metaUrl = "https://www.googleapis.com/drive/v3/files";
  const metaResponse = await fetch(metaUrl, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      name: filename,
      mimeType: "text/markdown",
      description: "Neutral Safety Audit Report generated by SafeGuard Analyzer v1.0"
    })
  });

  if (!metaResponse.ok) {
    const err = await metaResponse.json().catch(() => ({}));
    throw new Error(err?.error?.message || `Failed to create file metadata on Google Drive (HTTP ${metaResponse.status})`);
  }

  const metadata = await metaResponse.json();
  const fileId = metadata.id;

  // Step 2: Upload content using media patch
  const mediaUrl = `https://www.googleapis.com/upload/drive/v3/files/${fileId}?uploadType=media`;
  const mediaResponse = await fetch(mediaUrl, {
    method: "PATCH",
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "text/markdown"
    },
    body: markdownContent
  });

  if (!mediaResponse.ok) {
    throw new Error(`Failed to upload report body to Google Drive (HTTP ${mediaResponse.status})`);
  }

  return {
    id: fileId,
    name: filename,
    mimeType: "text/markdown"
  };
};
